Profile logos (About)

linkedin.png, github.png, facebook.png and whatsapp.png are the LinkedIn,
GitHub, Facebook and WhatsApp buttons in About (Profiles shows only the
logos; a click opens the profile in the browser). Put in or replace the
official logo files (same names, .png or .svg). Without a file, About
shows a simple icon.
