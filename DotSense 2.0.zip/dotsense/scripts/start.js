// npm start: runs DotSense from its source.
//
// On macOS the development runtime is an app called "Electron", so the menu bar and the Dock would
// say "Electron" and show its icon. This makes a copy of that runtime named DotSense, with the
// DotSense icon, and runs the copy. The copy is made once (again after an Electron update), in
// node_modules/.dotsense-dev, as an APFS clone where possible so it takes no extra disk space.
// If the copy cannot be made or does not start, the normal runtime is used - DotSense always starts.
// Windows and Linux: the window already shows the DotSense name and icon; the runtime runs as it is.
'use strict';
const { spawn, execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const runtime = require('electron');   // the path of the Electron program
const args = ['.', ...process.argv.slice(2)];

function macCopy() {
  const src = path.resolve(runtime, '..', '..', '..');   // …/Electron.app
  if (!/\.app$/.test(src) || !fs.existsSync(src)) throw new Error('Electron.app not found');
  const dir = path.join(root, 'node_modules', '.dotsense-dev');
  const app = path.join(dir, 'DotSense.app');
  const bin = path.join(app, 'Contents', 'MacOS', path.basename(runtime));
  const icon = path.join(root, 'build', 'icon.icns');
  const stampFile = path.join(dir, 'stamp.json');
  const want = JSON.stringify({ electron: require('electron/package.json').version, icon: fs.existsSync(icon) ? fs.statSync(icon).size : 0, v: 1 });
  let have = '';
  try { have = fs.readFileSync(stampFile, 'utf8'); } catch (_) { /* not made yet */ }
  if (have === 'failed ' + want) return null;   // it did not start last time: use the normal runtime
  if (have === want && fs.existsSync(bin)) return { bin, stampFile, want };

  console.log('DotSense: preparing the DotSense app for "npm start" (first start only, a few seconds)…');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  try { execFileSync('cp', ['-Rc', src, app], { stdio: 'ignore' }); }   // APFS clone
  catch (_) { fs.rmSync(app, { recursive: true, force: true }); execFileSync('cp', ['-R', src, app], { stdio: 'ignore' }); }
  const plist = path.join(app, 'Contents', 'Info.plist');
  // the name in the menu bar and the Dock (the bundle id stays, so the runtime's helpers still match it)
  for (const key of ['CFBundleName', 'CFBundleDisplayName']) execFileSync('plutil', ['-replace', key, '-string', 'DotSense', plist]);
  if (fs.existsSync(icon)) {
    let name = 'electron.icns';
    try { name = execFileSync('plutil', ['-extract', 'CFBundleIconFile', 'raw', plist]).toString().trim() || name; } catch (_) { /* older macOS: the usual name */ }
    fs.copyFileSync(icon, path.join(app, 'Contents', 'Resources', /\.icns$/i.test(name) ? name : name + '.icns'));
  }
  // the changed app needs a new (local, ad-hoc) signature, or macOS will not start it
  execFileSync('codesign', ['--force', '--deep', '--sign', '-', app], { stdio: 'ignore' });
  fs.writeFileSync(stampFile, want);
  return { bin, stampFile, want };
}

function run(bin, onEarlyFail) {
  const started = Date.now();
  let done = false;
  const child = spawn(bin, args, { cwd: root, stdio: 'inherit', env: process.env });
  child.on('error', e => {
    if (done) return;
    done = true;
    if (onEarlyFail) onEarlyFail(e);
    else { console.error('DotSense could not start:', e.message); process.exit(1); }
  });
  child.on('exit', (code, signal) => {
    if (done) return;
    done = true;
    // killed or failed at once (a missing signature, for example): try the normal runtime
    if (onEarlyFail && (signal || code) && Date.now() - started < 4000) { onEarlyFail(new Error(signal || 'exit code ' + code)); return; }
    process.exit(code == null ? 1 : code);
  });
}

let copy = null;
if (process.platform === 'darwin') {
  try { copy = macCopy(); } catch (e) { console.warn(`DotSense: running the Electron runtime as it is (${e.message}).`); }
}
if (copy) {
  run(copy.bin, e => {
    console.warn(`DotSense: the DotSense app did not start (${e.message}); running the Electron runtime as it is.`);
    try { fs.writeFileSync(copy.stampFile, 'failed ' + copy.want); } catch (_) { /* try again next time */ }
    run(runtime);
  });
} else {
  run(runtime);
}
