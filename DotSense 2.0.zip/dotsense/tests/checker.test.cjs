// DotSense Auto correct tests: node tests/checker.test.cjs
const assert = require('node:assert/strict');
const C = require('../checker');
let passed = 0;
const test = (name, fn) => { fn(); passed++; };
// the issues as "found -> first option" (and the kind when asked)
const fixes = (text, opts) => C.findIssues(text, opts).map(i => `${i.found}->${i.options.join('|')}`);
const spellOf = obj => ({ spell: new Map(Object.entries(obj)) });

test('the example: im rubai -> I\'m / I am, and rubai is looked up', () => {
  const is = C.findIssues('im rubai', spellOf({ rubai: ['Dubai', 'ruby'] }));
  assert.deepEqual(is.map(i => [i.found, i.options, i.kind]), [['im', ["I'm", 'I am'], 'grammar'], ['rubai', ['Dubai', 'ruby'], 'spelling']]);
  assert.deepEqual(C.englishWords('im rubai and Rina said so'), ['rubai', 'and', 'said', 'so'], 'names in the middle of a sentence are skipped');
});

test('missing apostrophes keep the capitals', () => {
  assert.deepEqual(fixes('I dont go'), ["dont->don't|do not"]);
  assert.deepEqual(fixes('dont go'), ["dont->Don't|Do not"], 'at the start of a sentence');
  assert.deepEqual(fixes('I think Dont'), ["Dont->Don't|Do not"]);
  assert.deepEqual(fixes('They said DONT'), ["DONT->DON'T|DO NOT"]);
  assert.deepEqual(fixes("It's fine, don't worry."), [], 'already right');
  assert.deepEqual(fixes('We cant and theyre sure.'), ["cant->can't|cannot", "theyre->they're|they are"]);
});

test('i -> I, joined words, of -> have, then -> than', () => {
  assert.deepEqual(fixes('Yes i know and i\'m here, i.e. now.'), ['Yes->Yes,', 'i->I', "i'm->I'm"]);
  assert.deepEqual(fixes('So alot of people.'), ['alot->a lot']);
  assert.deepEqual(fixes('I could of gone.'), ['could of->could have']);
  assert.deepEqual(fixes('It is better then that.'), ['then->than']);
});

test('subject and verb', () => {
  assert.deepEqual(fixes('They is here'), ['They is->They are']);
  assert.deepEqual(fixes('So he dont care.'), ["he dont->he doesn't"]);
  assert.deepEqual(fixes('So we was late.'), ['we was->we were']);
  assert.deepEqual(fixes('So she have a pen.'), ['she have->she has']);
  assert.deepEqual(fixes('Does she have a pen?'), [], 'a question is right');
  assert.deepEqual(fixes('So i is ok.'), ['i is->I am']);
});

test('a / an by sound', () => {
  assert.deepEqual(fixes('I ate a apple and an banana.'), ['a->an', 'an->a']);
  assert.deepEqual(fixes('I saw an hour, a university, an umbrella, a euro.'), []);
  assert.deepEqual(fixes('It is an FBI case, plan A is fine.'), [], 'short forms and labels are left alone');
  assert.deepEqual(fixes('A apple'), ['A->An']);
});

test('capital letter at the start of a sentence, not after e.g. or ...', () => {
  assert.deepEqual(fixes('hello. this is it'), ['hello->Hello', 'this->This', '->.']);
  assert.deepEqual(fixes('See e.g. this. Wait... then go.'), []);
  assert.deepEqual(fixes('Title\n\nnext part'), ['next->Next']);
});

test('punctuation and spaces', () => {
  assert.deepEqual(fixes('Hello , world'), [' ,->,']);
  assert.deepEqual(fixes('One,two'), [',->, ']);
  assert.deepEqual(fixes('Stop.Go now'), ['.->. ']);
  assert.deepEqual(fixes('Why?because'), ['?->? ']);
  assert.deepEqual(fixes('Two  spaces'), ['  -> ']);
  assert.deepEqual(fixes('1,000 and 3.14 and 10:30 ok.'), [], 'numbers are left alone');
  assert.deepEqual(fixes('The the end'), ['The the->The']);
  assert.deepEqual(fixes('I had had enough.'), []);
});

test('the end of a paragraph gets a full stop (long lines only)', () => {
  assert.deepEqual(fixes('My Favorite Teacher'), [], 'a title');
  const is = C.findIssues('She teaches us science with great patience\n\nNext');
  assert.equal(is.length, 1);
  assert.equal(is[0].start, is[0].end, 'inserted');
  assert.equal(is[0].start, 'She teaches us science with great patience'.length);
  assert.deepEqual(is[0].options, ['.']);
  assert.deepEqual(fixes('She teaches us science with great\npatience every day of the week.'), [], 'the sentence goes on');
});

test('links, e-mail addresses and page breaks are left alone', () => {
  assert.deepEqual(fixes('Mail me@dotsense.app,now at https://x.org/a?b=c&d=e ok.'), []);
  assert.deepEqual(fixes('One.\n[[New Page 2]]\nnext page'), ['next->Next']);
  assert.deepEqual(C.englishWords('see https://dotsense.app/help now'), ['see', 'now']);
});

test('Bangla: danda, spaces, repeated words', () => {
  assert.deepEqual(fixes('আমি ভালো আছি.'), ['.->।']);
  assert.deepEqual(fixes('আমি ভালো আছি.তুমি?'), ['.->। ']);
  assert.deepEqual(fixes('তুমি কেমন আছ ?'), [' ?->?']);
  assert.deepEqual(fixes('ভালো আছি।তুমি'), ['।->। ']);
  assert.deepEqual(fixes('যাব।।'), ['।।->।']);
  assert.deepEqual(fixes('আমি এবং এবং তুমি।'), ['এবং এবং->এবং']);
  assert.deepEqual(fixes('ধীরে ধীরে চলো'), [], 'repeated on purpose');
  assert.deepEqual(fixes('আমি তাকে খুব শ্রদ্ধা করি'), ['->।'], 'a Bangla sentence at the end of a paragraph');
  assert.deepEqual(fixes('প্রিয় শিক্ষক'), [], 'a title');
});

test('Bangla: common spelling mistakes, also with an ending', () => {
  assert.deepEqual(fixes('পরিক্ষা'), ['পরিক্ষা->পরীক্ষা']);
  assert.deepEqual(fixes('কারনে'), ['কারনে->কারণে']);
  assert.deepEqual(fixes('বাড়ী'.normalize('NFD')), [`${'বাড়ী'.normalize('NFD')}->${'বাড়ি'.normalize('NFC')}`], 'either way of writing ড়');
  assert.deepEqual(fixes('শ্রেনী'), ['শ্রেনী->শ্রেণি|শ্রেণী']);
  assert.deepEqual(fixes('দেশীয় পণ্য'), [], 'দেশীয় is right');
  assert.deepEqual(fixes('পরীক্ষা কারণ বাড়ি'), [], 'right spellings');
  for (const [wrong, ...right] of C.BN_SPELLING) {
    assert.notEqual(wrong, right[0], wrong);
    assert.ok(!C.BN_SPELLING.some(r => r[0] === right[0]), 'a right spelling is never in the wrong list: ' + right[0]);
  }
});

test('Ignore and my words', () => {
  const is = C.findIssues('I dont', {});
  assert.deepEqual(C.findIssues('I dont', { ignore: new Set([is[0].key]) }), []);
  assert.deepEqual(fixes('I am rubai', { spell: new Map([['rubai', ['Dubai']]]), myWords: new Set(['rubai']) }), []);
  assert.deepEqual(fixes('I zzqx', { spell: new Map([['zzqx', []]]) }), ['zzqx->'], 'no suggestion: still shown (Ignore / Add)');
});

test('Fix all: every first suggestion, in one go, places stay right', () => {
  const text = 'i dont know , it is a apple.Then go';
  const is = C.findIssues(text);
  assert.equal(C.applyAll(text, is), "I don't know, it is an apple. Then go.");
});

test('the example words: sentense and punctuaton are found at once, with the right spelling first', () => {
  const is = C.findIssues('This is a sentense with bad punctuaton.');
  assert.deepEqual(is.map(i => [i.found, i.options, i.kind, i.sure]), [['sentense', ['sentence'], 'spelling', true], ['punctuaton', ['punctuation'], 'spelling', true]]);
  assert.deepEqual(fixes('Teh freind said wich.'), ['Teh->The', 'freind->friend', 'wich->which'], 'the capital stays');
  assert.deepEqual(C.englishWords('a sentense here'), ['here'], 'known ones are not sent to the dictionary');
  // the dictionary's suggestions: the closest first; only a capital missing -> a capital fix (sure)
  assert.deepEqual(C.rankSuggestions('sentense', ['sentences', 'sentience', 'sentence']), ['sentence', 'sentences', 'sentience']);
  assert.deepEqual(C.rankSuggestions('tabel', ['Mabel', 'table', 'label']), ['table', 'label', 'Mabel'], 'a name after words');
  const d = C.findIssues('We went to dhaka and saw uiu.', spellOf({ dhaka: ['Shaka', 'Dhaka'], uiu: ['usu'] }));
  assert.deepEqual(d.map(i => [i.found, i.kind, i.options[0], i.sure]), [['dhaka', 'capital', 'Dhaka', true], ['uiu', 'spelling', 'usu', false]]);
});

test('at the start of a sentence a spelling fix starts with a capital (and a name can keep its own spelling)', () => {
  assert.deepEqual(fixes('teh end'), ['teh->The']);
  assert.deepEqual(fixes('rubai is here', spellOf({ rubai: ['Dubai'] })), ['rubai->Dubai|Rubai']);
});

test('names, days, months and languages get a capital letter', () => {
  assert.deepEqual(fixes('We speak english on monday in bangladesh.'), ['english->English', 'monday->Monday', 'bangladesh->Bangladesh']);
  assert.deepEqual(fixes('In may we march on.'), [], 'may and march are words too');
});

test('a question ends with a question mark (English and Bangla)', () => {
  assert.deepEqual(fixes('Where do you live.'), ['.->?']);
  assert.deepEqual(fixes('What is your name'), ['->?']);
  assert.deepEqual(fixes('How many people are there'), ['->?']);
  assert.deepEqual(fixes('Is it raining. I think so.'), ['.->?']);
  assert.deepEqual(fixes("It's nice, isn't it"), ['->?'], 'a tag question');
  for (const t of ['Do it now.', 'Have a nice day.', 'May the force be with you.', 'Should you need help, call me.',
    'When I was young, I played football.', 'What I want is peace.', 'How nice it is!', 'Can openers are useful.']) {
    assert.deepEqual(fixes(t), [], 'not a question: ' + t);
  }
  assert.deepEqual(fixes('What a beautiful day'), ['->!|.'], 'an exclamation: ! or .');
  assert.deepEqual(fixes('তুমি কেমন আছ।'), ['।->?']);
  assert.deepEqual(fixes('তোমার নাম কি'), ['->?']);
  assert.deepEqual(fixes('সে আসবে কি না, আমি জানি না।'), [], 'কি না is not a question');
  assert.ok(C.isQuestion('Are you ok') && C.isQuestion('Does it work') && !C.isQuestion('Do your homework'));
});

test('one mark, not two; commas after opening words; brackets', () => {
  assert.deepEqual(fixes('Hello!! How are you??? Fine,, thanks..'), ['!!->!', '???->?', ',,->,', '..->.|...']);
  assert.deepEqual(fixes('Wait.... I am coming ,.'), ['....->...', ',.->.']);
  assert.deepEqual(fixes('Really?. Yes.'), ['?.->?']);
  assert.deepEqual(fixes('He said ( hello ) to me.'), ['( ->(', ' )->)']);
  assert.deepEqual(fixes('However we stayed. For example we read. No I did not. Of course not.'), ['However->However,', 'For example->For example,', 'No->No,']);
  assert.deepEqual(fixes('however we stayed home.'), ['however->However,'], 'the capital too, in one fix');
  assert.deepEqual(fixes('However hard I try, it fails. No one came. Well done.'), []);
  assert.deepEqual(fixes('Wait... then go. See 1..10 and 3.14 now.'), [], 'an ellipsis and numbers are fine');
});

test('sentence mistakes: subject and verb', () => {
  assert.deepEqual(fixes('He go to school and she like apples.'), ['He go->He goes', 'she like->she likes']);
  assert.deepEqual(fixes('We goes home and they does it.'), ['We goes->We go', 'they does->they do']);
  assert.deepEqual(fixes('I has a pen.'), ['I has->I have']);
  assert.deepEqual(fixes('It make sense and I think it work.'), ['It make->It makes', 'it work->it works']);
  assert.deepEqual(fixes('There is many people. This are my books.'), ['There is->There are', 'This are->These are|This is']);
  assert.deepEqual(fixes('I seen him and we done it.'), ['I seen->I saw|I have seen', 'we done->we did|we have done']);
  assert.deepEqual(fixes('He use to live here.'), ['He use->He used']);
  assert.deepEqual(fixes('He is more taller than me.'), ['more taller->taller']);
  assert.deepEqual(fixes('Me and him went home.'), ['Me and him->He and I']);
  for (const t of ['Does he go to school?', 'Can she swim?', 'He and she go to school.', 'Let it go and make it work.',
    'Thank you goes a long way.', 'Have you seen my keys?', 'Are you done?', 'The books that are here are mine.',
    'If he had known, he would have come.', 'He can speak three languages.', 'I saw it happen.']) {
    assert.deepEqual(fixes(t), [], 'right: ' + t);
  }
});

test('sentence mistakes: its / your / there / too / double negatives', () => {
  assert.deepEqual(fixes('Its a nice day.'), ["Its->It's"]);
  assert.deepEqual(fixes("The dog wagged it's tail."), ["it's->its"]);
  assert.deepEqual(fixes('Thanks. Your welcome.'), ["Your->You're"]);
  assert.deepEqual(fixes('There going home.'), ["There->They're"]);
  assert.deepEqual(fixes("They're car is red."), ["They're->Their"]);
  assert.deepEqual(fixes('It is to late.'), ['to->too']);
  assert.deepEqual(fixes('Me to.'), ['to->too']);
  assert.deepEqual(fixes("I don't know nothing."), ['nothing->anything']);
  for (const t of ['Its roots go deep.', 'The dog wagged its tail.', "You're welcome.", 'Thank you for your welcome message.',
    "They're going home.", 'Their house is big.', 'It is too late.', 'I went to school.', "We don't need anything."]) {
    assert.deepEqual(fixes(t), [], 'right: ' + t);
  }
});

test('the end of a paragraph: four words or more, not a title or a list', () => {
  assert.deepEqual(fixes('i live in dhaka'), ['i->I', 'dhaka->Dhaka', '->.']);
  assert.deepEqual(fixes('My Favorite Teacher Is Here'), [], 'a title');
  assert.deepEqual(fixes('- buy milk and eggs'), [], 'a list');
  assert.deepEqual(fixes('Go home now'), [], 'short');
});

test('Fix all takes the sure ones: rules and common misspellings, not the dictionary guesses', () => {
  const text = 'i has a sentense with rubai';
  const is = C.findIssues(text, spellOf({ rubai: ['Dubai'] }));
  assert.equal(C.applyAll(text, is.filter(i => i.sure)), 'I have a sentence with rubai.');
});

test('long texts stay quick', () => {
  const big = ('this is a sentence with teh words and dont stop , ok. ').repeat(4000);
  const t = Date.now();
  const is = C.findIssues(big);
  assert.ok(is.length > 8000);
  assert.ok(Date.now() - t < 3000, 'took ' + (Date.now() - t) + ' ms');
});

console.log(`PASS checker: ${passed} tests`);
