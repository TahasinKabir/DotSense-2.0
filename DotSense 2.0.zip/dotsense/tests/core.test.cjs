// DotSense core tests: node tests/core.test.cjs
const assert = require('node:assert/strict');
const B = require('../core');
const s = { ...B.DEFAULTS };
let passed = 0;
const test = (name, fn) => { fn(); passed++; };

// Reference: dot positions from the original one-line Braille Gcode app (index.html build()).
function originalAppDots(sentence, o) {
  const LETTER_DOTS = B.LETTERS, DIGIT_DOTS = B.DIGITS, PUNCT_DOTS = B.PUNCT, NUMBER_SIGN = [3, 4, 5, 6];
  const DOT_POS = { 1: [0, 0], 2: [0, 1], 3: [0, 2], 4: [1, 0], 5: [1, 1], 6: [1, 2] };
  const out = []; let cellIndex = 0, inNumber = false;
  const punch = dots => { const baseX = o.originX + cellIndex * o.cellPitch; for (const d of dots) { const [c, r] = DOT_POS[d]; out.push([baseX + c * o.dotPitch, o.originY - r * o.dotPitch]); } cellIndex++; };
  for (const ch of sentence) {
    if (ch === ' ') { cellIndex++; inNumber = false; continue; }
    if (ch >= '0' && ch <= '9') { if (!inNumber) { punch(NUMBER_SIGN); inNumber = true; } punch(DIGIT_DOTS[ch]); continue; }
    inNumber = false;
    const low = ch.toLowerCase();
    const dots = (low >= 'a' && low <= 'z') ? LETTER_DOTS[low] : PUNCT_DOTS[ch];
    if (!dots) { cellIndex++; continue; }
    punch(dots);
  }
  return out;
}

test('geometry of defaults', () => {
  const g = B.geometry(s);
  assert.equal(g.cols, 18); assert.equal(g.rows, 9);
});

test('same dots as original app for one-line text', () => {
  const o = { ...s, originX: 10, originY: 15, width: 2000 }; // wide: no wrapping, like the original app
  for (const sentence of ['HELLO WORLD 123!', 'Braille, dots; yes: no. why? it\'s-ok', 'A B  C', '2026 x']) {
    const r = B.layout(sentence, o);
    const pts = B.points(r.pages[0], r.settings).map(p => [p.x, p.y]);
    assert.deepEqual(pts, originalAppDots(sentence.replace(/ +/g, ' '), o), sentence);
  }
});

test('number sign and letter sign', () => {
  assert.deepEqual(B.cellsFor('10').map(c => c.dots), [[3, 4, 5, 6], [1], [2, 4, 5]]);
  assert.deepEqual(B.cellsFor('1a').map(c => c.dots), [[3, 4, 5, 6], [1], [5, 6], [1]]);
  assert.deepEqual(B.cellsFor('1k').map(c => c.dots), [[3, 4, 5, 6], [1], [1, 3]]);
});

test('auto-wrap lines and pages', () => {
  assert.equal(B.layout('a\nb', s).pages[0].length, 2);
  assert.equal(B.layout('a[[PAGE]]b', s).pages.length, 2);
  assert.equal(B.layout('x\n'.repeat(8) + 'x', s).pages.length, 1);
  assert.equal(B.layout('x\n'.repeat(9) + 'x', s).pages.length, 2);
  assert.equal(B.layout('a'.repeat(18), s).pages[0][0].length, 18);
  assert.equal(B.layout('a'.repeat(19), s).pages[0].length, 2);
  const words = B.layout('hello world '.repeat(40), s);
  for (const p of words.pages) for (const l of p) {
    assert.ok(l.length <= 18);
    assert.notEqual(l[0].kind, 'space');
  }
  assert.equal(B.layout('hello world', s).pages[0].flat().map(c => c.ch).join(''), 'HELLO WORLD');
});

test('wrap keeps words whole', () => {
  const r = B.layout('aaaaaaaaaa bbbbbbbbbb', s); // 10 + 1 + 10 > 18
  assert.deepEqual(r.pages[0].map(B.lineText), ['AAAAAAAAAA', 'BBBBBBBBBB']);
});

test('numeric continuation lines get a number sign', () => {
  const numeric = B.layout('1234567890'.repeat(10), s);
  for (const p of numeric.pages) for (const l of p) assert.equal(l[0].ch, '#');
});

test('trailing page break does not add a blank sheet', () => {
  assert.equal(B.layout('a[[PAGE]]', s).pages.length, 1);
  assert.equal(B.layout('a\n[[PAGE]]\n', s).pages.length, 1);
  assert.equal(B.layout('', s).pages.length, 0);
  assert.equal(B.layout('   \n  ', s).pages.length, 0);
});

test('page break markers: [[New Page 3]], [[New Page]], [[PAGE]] and a form feed', () => {
  const lines = r => r.pages.map(p => p.map(B.lineText).join('/'));
  for (const mark of ['[[PAGE]]', '[[New Page]]', '[[New Page 7]]', '[[new page 2]]', '[[ NEW  PAGE 12 ]]', '[[Page3]]', '[[newpage]]', '[[New Page 3]]', '\f']) {
    assert.deepEqual(lines(B.layout(`one\n${mark}\ntwo`, s)), ['ONE', 'TWO'], JSON.stringify(mark));
    assert.deepEqual(lines(B.layout(`one ${mark} two`, s)), ['ONE', 'TWO'], JSON.stringify(mark));
  }
  // not page breaks: other words, a line break inside, single brackets, no number
  for (const text of ['[[New Pages]]', '[[Next Page]]', '[New Page]', '[[New\nPage]]', '[[New Page x]]', '[[New Page 3]', 'new page']) {
    assert.equal(B.layout(text, s).pages.length, 1, text);
  }
  assert.equal(B.PAGE_MARK.test('x [[New Page 3]] y'), true);
  assert.equal(B.PAGE_MARK.test('[[New Page three]]'), false);
  // the size fit ignores the markers
  const paper = { w: 210, h: 297, orientation: 'portrait', margin: 10 };
  assert.deepEqual(B.fitScale(' [[New Page 2]] ', s, paper, 'fit'), { pct: 100, fits: true });
  const short = B.fitScale('HELLO[[New Page 2]]WORLD', s, paper, 'fit');
  assert.deepEqual(short, B.fitScale('HELLO[[PAGE]]WORLD', s, paper, 'fit'));
  assert.equal(short.pct, 200);
});

test('page breaks report the page they start (for the [[New Page 3]] numbers)', () => {
  const b = t => B.layout(t, s).breaks;
  assert.deepEqual(b('no breaks here'), []);
  assert.deepEqual(b('one[[New Page]]two[[New Page]]three'), [1, 2]);
  // 9 lines per page: 12 lines take two pages, so the break after them starts page 3
  assert.deepEqual(b('x\n'.repeat(12) + '[[New Page 2]]\nnext'), [2]);
  // exactly one full page before the break
  assert.deepEqual(b('x\n'.repeat(8) + 'x\n[[PAGE]]\ny'), [1]);
  // at the start (the first sheet stays blank), twice in a row (a blank sheet between), at the end
  assert.deepEqual(b('[[PAGE]]\nfirst'), [1]);
  assert.deepEqual(b('a\n[[PAGE]]\n[[PAGE]]\nb'), [1, 2]);
  assert.equal(B.layout('a\n[[PAGE]]\n[[PAGE]]\nb', s).pages.length, 3);
  assert.deepEqual(b('a\n[[New Page 9]]\n'), [1]);
  assert.equal(B.layout('a\n[[New Page 9]]\n', s).pages.length, 1);
  // form feeds count in the same order
  assert.deepEqual(b('a\fb[[New Page]]c'), [1, 2]);
});

test('unsupported characters are reported, not silently dropped', () => {
  const r = B.layout('love ♥ and ₹5', s);
  assert.deepEqual(r.unsupported.map(u => u.ch).sort(), ['₹', '♥']);
  assert.equal(r.pages[0].flat().filter(c => c.kind === 'unknown').length, 2);
  assert.ok(B.gcode(r.pages[0], r.settings).includes("(no braille mapping for '?', skipped)"), 'G-code notes stay ASCII');
});

test('normalizes hyphens, the ellipsis and soft hyphens (quotes and dashes keep their own signs)', () => {
  assert.equal(B.normalize('“Hi” — it’s­ ok… a‐b'), '“Hi” — it’s ok... a-b');
  assert.equal(B.layout('“Hi” — it’s ok…', s).unsupported.length, 0);
});

// Unicode braille of one line (a very wide area: no wrapping)
const uni = cells => cells.map(c => (c.kind === 'space' ? '⠀' : String.fromCharCode(0x2800 + c.dots.reduce((b, d) => b | (1 << (d - 1)), 0)))).join('');
const brl = text => uni(B.layout(text, { ...s, width: 2000 }).pages[0][0]);

test('signs and symbols as in UEB (the same as liblouis en-ueb-g1)', () => {
  // expected: liblouis 3.29 lou_translate unicode.dis,en-ueb-g1.ctb (small letters: capitals are not marked here)
  const cases = [
    ['@ # $ % & * + = / \\ _ ~ ^ | < >', '⠈⠁⠀⠸⠹⠀⠈⠎⠀⠨⠴⠀⠈⠯⠀⠐⠔⠀⠐⠖⠀⠐⠶⠀⠸⠌⠀⠸⠡⠀⠨⠤⠀⠈⠔⠀⠈⠢⠀⠸⠳⠀⠈⠣⠀⠈⠜'],
    ['(a) [b] {c} <d>', '⠐⠣⠁⠐⠜⠀⠨⠣⠃⠨⠜⠀⠸⠣⠉⠸⠜⠀⠈⠣⠙⠈⠜'],
    ['name@mail.com https://dotsense.app/a_b?x=1&y=2', '⠝⠁⠍⠑⠈⠁⠍⠁⠊⠇⠲⠉⠕⠍⠀⠓⠞⠞⠏⠎⠒⠸⠌⠸⠌⠙⠕⠞⠎⠑⠝⠎⠑⠲⠁⠏⠏⠸⠌⠁⠨⠤⠃⠰⠦⠭⠐⠶⠼⠁⠈⠯⠽⠐⠶⠼⠃'],
    ['"hello" “hi” ‘x’ it’s don\'t', '⠦⠓⠑⠇⠇⠕⠴⠀⠦⠓⠊⠴⠀⠠⠦⠭⠠⠴⠀⠊⠞⠄⠎⠀⠙⠕⠝⠄⠞'],
    ['3.14 1,000 10:30 a,b a!b ?', '⠼⠉⠲⠁⠙⠀⠼⠁⠂⠚⠚⠚⠀⠼⠁⠚⠒⠼⠉⠚⠀⠁⠰⠂⠃⠀⠁⠰⠖⠃⠀⠰⠦'],
    ['x – y — z ― w', '⠭⠀⠠⠤⠀⠽⠀⠠⠤⠀⠵⠀⠐⠠⠤⠀⠺'],
    ['€5 £3 ¥7 ¢9 ° © ® ™ § ¶ • † ‡ ± × ÷ ′ ″ … « » ¿ ¡', '⠈⠑⠼⠑⠀⠈⠇⠼⠉⠀⠈⠽⠼⠛⠀⠈⠉⠼⠊⠀⠘⠚⠀⠘⠉⠀⠘⠗⠀⠘⠞⠀⠘⠎⠀⠘⠏⠀⠸⠲⠀⠈⠠⠹⠀⠈⠠⠻⠀⠸⠖⠀⠐⠦⠀⠐⠌⠀⠶⠀⠶⠶⠀⠲⠲⠲⠀⠸⠦⠀⠸⠴⠀⠘⠰⠦⠀⠘⠰⠖'],
    ['café niño über façade crème straße øre', '⠉⠁⠋⠘⠌⠑⠀⠝⠊⠘⠻⠝⠕⠀⠘⠒⠥⠃⠑⠗⠀⠋⠁⠘⠯⠉⠁⠙⠑⠀⠉⠗⠘⠡⠑⠍⠑⠀⠎⠞⠗⠁⠨⠮⠑⠀⠈⠡⠕⠗⠑'],
    ['1é 1a 1k 5j 1.a 3,b 1.5a', '⠼⠁⠘⠌⠑⠀⠼⠁⠰⠁⠀⠼⠁⠅⠀⠼⠑⠰⠚⠀⠼⠁⠲⠰⠁⠀⠼⠉⠂⠰⠃⠀⠼⠁⠲⠑⠰⠁'],
    ['2½ ¾ ⅓ m² x³', '⠼⠃⠼⠁⠌⠃⠀⠼⠉⠌⠙⠀⠼⠁⠌⠉⠀⠍⠰⠔⠼⠃⠀⠭⠰⠔⠼⠉'],
    ['← ↑ → ↓ − ≠ ≤ ≥ ≈ ∞ √ ✓', '⠰⠳⠪⠀⠰⠳⠬⠀⠰⠳⠕⠀⠰⠳⠩⠀⠐⠤⠀⠐⠶⠈⠱⠀⠸⠈⠣⠀⠸⠈⠜⠀⠘⠔⠀⠼⠿⠀⠐⠩⠀⠈⠩'],
    ['α β γ π σ ω μ', '⠨⠁⠀⠨⠃⠀⠨⠛⠀⠨⠏⠀⠨⠎⠀⠨⠺⠀⠨⠍'],
    ['∀ ∃ ∈ ∉ ⊂ ⊆ ∩ ∪ ∫ ∑ ∏ ∂ ∇ ≡ ∝ ∠ ⊥ ∴ ∵', '⠘⠁⠀⠘⠢⠀⠘⠑⠀⠘⠑⠈⠱⠀⠘⠣⠀⠸⠘⠣⠀⠨⠦⠀⠨⠖⠀⠮⠀⠠⠨⠎⠀⠠⠨⠏⠀⠈⠙⠀⠘⠙⠀⠸⠿⠀⠸⠐⠶⠀⠸⠪⠀⠼⠤⠀⠠⠡⠀⠈⠌'],
    ['⇒ ⇐ ⇑ ⇓ ↗ ↘ ↙ ↖ ↵', '⠰⠳⠶⠕⠀⠰⠳⠶⠪⠀⠰⠳⠶⠬⠀⠰⠳⠶⠩⠀⠰⠳⠎⠀⠰⠳⠣⠀⠰⠳⠜⠀⠰⠳⠱⠀⠰⠳⠲⠩'],
    ['■ □ ▲ △ ○ ● ♀ ♂ ♭ ♮ ♯ ✔', '⠸⠫⠼⠙⠀⠫⠼⠙⠀⠸⠫⠼⠉⠀⠫⠼⠉⠀⠫⠿⠀⠐⠔⠀⠘⠭⠀⠘⠽⠀⠼⠣⠀⠼⠡⠀⠼⠩⠀⠈⠩'],
    ['æ œ ð þ ŋ ħ', '⠁⠘⠖⠑⠀⠕⠘⠖⠑⠀⠼⠫⠀⠼⠮⠀⠘⠝⠀⠈⠒⠓']
  ];
  for (const [text, want] of cases) {
    assert.equal(brl(text), want, text);
    assert.deepEqual(B.layout(text, s).unsupported, [], text);
  }
  // capitals are not marked, so these read the same
  assert.equal(brl('CAFÉ Øre'), brl('café øre'));
  // Greek capitals like the small letters; ligatures from PDFs become letters; after a number, a letter
  // starting with an a-j cell takes the letter sign (liblouis leaves it out: ⠼⠁⠁ would read 11)
  assert.equal(brl('ΑΒΓ Ω'), brl('αβγ ω'));
  assert.equal(brl('ﬁnd ﬂow ﬀ'), brl('find flow ff'));
  assert.equal(brl('1æ 2π'), '⠼⠁⠰⠁⠘⠖⠑⠀⠼⠃⠨⠏');
  // a letter with a separate accent mark (not composed)
  assert.equal(brl('q\u0301'), '⠘⠌⠟');
  assert.equal(brl('cafe\u0301'), brl('café'));
});

test('quotes follow the words: opening, closing, apostrophe; a ‘single quote’ stays open across words', () => {
  assert.equal(brl('‘I’m here,’ she said.'), '⠠⠦⠊⠄⠍⠀⠓⠑⠗⠑⠂⠠⠴⠀⠎⠓⠑⠀⠎⠁⠊⠙⠲');
  assert.equal(brl('the students’ books'), '⠞⠓⠑⠀⠎⠞⠥⠙⠑⠝⠞⠎⠄⠀⠃⠕⠕⠅⠎', 'no quote open: an apostrophe');
  assert.equal(brl('He said "yes."'), '⠓⠑⠀⠎⠁⠊⠙⠀⠦⠽⠑⠎⠲⠴');
  assert.equal(brl('"'), '⠠⠶', 'on its own: the quotation mark without direction');
  assert.equal(brl('why? (why?) ?!'), '⠺⠓⠽⠦⠀⠐⠣⠺⠓⠽⠦⠐⠜⠀⠰⠦⠖');
  assert.equal(brl('it´s it`s'), '⠊⠞⠄⠎⠀⠊⠞⠄⠎', 'accents typed for an apostrophe');
  // the first words of a long word that is split over lines keep the quote open
  const narrow = B.layout('‘abcdefghijklmnopqrstuvwxyz’', s);
  assert.equal(narrow.pages[0].length, 2);
  assert.equal(uni(narrow.pages[0][1]).slice(-2), '⠠⠴');
});

test('signs: G-code notes name them in ASCII, the window describes them', () => {
  const r = B.layout('a@b €5 é½', { ...s, width: 400 });
  const code = B.gcode(r.pages[0], r.settings);
  for (const note of ['; ===== PREFIX OF AT SIGN (@) =====', '; ===== AT SIGN (@) =====', '; ===== EURO =====', '; ===== E ACUTE =====', '; ===== ONE HALF =====', '; TEXT: A@B EUR5 E1/2']) {
    assert.ok(code.includes(note), note);
  }
  assert.ok(!/[^\x00-\x7f]/.test(code), 'ASCII only');
  const cells = r.pages[0].flat().filter(c => c.kind !== 'space');
  assert.deepEqual(cells.slice(0, 4).map(B.cellWhat), ['“A”', 'first cell of @ (at sign)', '@ (at sign)', '“B”']);
  assert.equal(B.cellWhat({ ch: 'g1', dots: [5, 6], kind: 'sign' }).split(' (')[0], 'grade 1 sign');
  // every sign in the table has cells, a name, and no warning
  for (const [ch, sym] of Object.entries(B.SYMBOLS)) {
    assert.ok(sym.cells.length && sym.cells.every(c => c.length && c.every(d => d >= 1 && d <= 6)) && sym.name, ch);
    assert.ok(B.isSupported(ch), ch);
  }
  assert.ok(Object.keys(B.SYMBOLS).length >= 220);
});

test('every dot stays inside the print area', () => {
  for (const input of ['Hello world '.repeat(300), '1234567890'.repeat(50), 'a'.repeat(1000), 'a\n\n\nb', 'a[[PAGE]]b']) {
    const r = B.layout(input, s);
    for (const page of r.pages) {
      assert.ok(page.length <= r.rows && page.every(l => l.length <= r.cols));
      for (const p of B.points(page, r.settings)) {
        assert.ok(p.x >= s.originX && p.x <= s.originX + s.width, 'x ' + p.x);
        assert.ok(p.y <= s.originY && p.y >= s.originY - s.height, 'y ' + p.y);
      }
    }
  }
});

test('G-code format matches original app style', () => {
  const r = B.layout('HELLO', s);
  const code = B.gcode(r.pages[0], r.settings, 0, 1);
  const lines = code.split('\n');
  assert.deepEqual(lines.slice(0, 4), ['%', 'G21', 'G90', 'G94']);
  assert.ok(code.includes('; DOTSENSE BRAILLE PRINT - PAGE 1 OF 1'));
  assert.ok(code.includes('; TEXT: HELLO'));
  assert.ok(code.includes('; ===== H ====='));
  assert.ok(code.includes('G1 Z-5 F1000'));
  assert.ok(code.includes('G4 P0.2'));
  assert.ok(code.includes('G0 X0 Y0'));
  assert.ok(code.endsWith('M5\nM30\n%'));
  // dot count = G1 plunges
  assert.equal(lines.filter(l => l.startsWith('G1 ')).length, r.stats.dots);
});

test('job lines map every line to its dot', () => {
  const r = B.layout('ab 12', s);
  const job = B.jobLines(r.pages[0], r.settings, 0, 1);
  assert.ok(job.lines.every(l => !l.code.startsWith('%') && !l.code.startsWith(';') && l.code.trim()));
  const dotLines = job.lines.filter(l => l.dot >= 0);
  assert.equal(dotLines.length, job.points.length * 4); // move, plunge, retract, dwell
  for (let k = 0; k < job.points.length; k++) {
    assert.deepEqual(dotLines.slice(k * 4, k * 4 + 4).map(l => [l.dot, l.phase]), [[k, 'move'], [k, 'plunge'], [k, 'retract'], [k, 'dwell']]);
  }
  const noDwell = B.jobLines(r.pages[0], { ...r.settings, dwell: 0 });
  assert.equal(noDwell.lines.filter(l => l.dot >= 0).length, job.points.length * 3);
});

test('settings validation', () => {
  assert.throws(() => B.layout('a', { ...s, cellPitch: 2 }), /Cell pitch/);
  assert.throws(() => B.layout('a', { ...s, width: 1 }), /at least 2/);
  assert.throws(() => B.layout('a', { ...s, clearZ: -6 }), /Clearance/);
  assert.throws(() => B.layout('a', { ...s, feed: 'abc' }), /Plunge feed/);
  assert.equal(B.layout('a', { ...s, feed: '800' }).settings.feed, 800);
});

test('estimate grows with dots', () => {
  const a = B.layout('a', s), b = B.layout('hello world', s);
  const ta = B.estimate(B.points(a.pages[0], s), s), tb = B.estimate(B.points(b.pages[0], s), s);
  assert.ok(ta > 0 && tb > ta);
  assert.ok(Math.abs(B.moveTime(100, 600, 0) - 10) < 1e-9);
});

test('large document stays fast', () => {
  const t = Date.now();
  const r = B.layout('The quick brown fox jumps over the lazy dog 1234. '.repeat(20000), s);
  assert.ok(r.pages.length > 100);
  assert.ok(Date.now() - t < 4000, 'layout took ' + (Date.now() - t) + 'ms');
});

test('invert print: Hello is punched as O L L E H with mirrored cells', () => {
  const r = B.layout('Hello', s);
  const m = B.mirrorPage(r.pages[0], r.cols);
  const used = m[0].map((c, i) => [c, i]).filter(([c]) => c.kind !== 'space');
  assert.deepEqual(used.map(([c]) => c.ch), ['O', 'L', 'L', 'E', 'H']);
  assert.deepEqual(used.map(([, i]) => i), [13, 14, 15, 16, 17]);          // right side of the sheet (top view)
  assert.deepEqual(used.map(([c]) => c.dots), [[2, 4, 6], [4, 5, 6], [4, 5, 6], [2, 4], [2, 4, 5]]);
  const code = B.gcode(r.pages[0], s, 0, 1, { invert: true });
  assert.ok(code.includes('; INVERT PRINT: MIRRORED'));
  assert.ok(code.indexOf('; ===== O =====') < code.indexOf('; ===== H ====='));
  assert.ok(code.includes('; TEXT: HELLO'), 'header keeps the reading text');
  assert.ok(!B.gcode(r.pages[0], s, 0, 1).includes('INVERT'));
});

test('invert print: turning the punched sheet over gives exactly the normal braille', () => {
  for (const text of ['Hello world', 'Braille 2026, page 12: ok!\nsecond line\n\nlast 1a', 'x\n'.repeat(12) + 'end']) {
    const r = B.layout(text, s);
    const span = (r.cols - 1) * s.cellPitch + s.dotPitch;
    r.pages.forEach((page, i) => {
      const normal = B.points(page, r.settings).map(p => `${p.x},${p.y}`).sort();
      const job = B.jobLines(page, r.settings, i, r.pages.length, { invert: true });
      const flipped = job.points.map(p => `${Math.round((2 * s.originX + span - p.x) * 1000) / 1000},${p.y}`).sort();
      assert.deepEqual(flipped, normal, text);
      for (const p of job.points) assert.ok(p.x >= s.originX && p.x <= s.originX + s.width && p.y <= s.originY && p.y >= s.originY - s.height);
      // every punched dot knows its reading-side dot
      const keys = B.points(page, r.settings).map(p => B.readingKey(p, r.cols, false)).sort();
      assert.deepEqual([...job.keys].sort(), keys);
      assert.equal(job.lines.filter(l => l.phase === 'plunge').length, job.points.length);
    });
  }
});

test('invert print: numbers and double mirror', () => {
  const r = B.layout('ab 12', s);
  const m = B.mirrorPage(r.pages[0], r.cols);
  assert.deepEqual(m[0].filter(c => c.kind !== 'space').map(c => c.ch), ['2', '1', '#', 'B', 'A']);
  const back = B.mirrorPage(m, r.cols);
  r.pages[0][0].forEach((cell, i) => assert.deepEqual(back[0][i].dots, cell.dots));
  assert.deepEqual(B.mirrorPage([[]], r.cols), [[]]);
  assert.equal(B.pagePoints(r.pages[0], s, { invert: true }).length, B.points(r.pages[0], s).length);
});

test('paper size: A4 portrait and landscape', () => {
  // dots start 2 mm inside the margin line (to the dot's edge): 2 + 1.2 mm radius = 3.2 mm to the centre
  const a = B.paperArea({ w: 210, h: 297, orientation: 'portrait', margin: 10 }, s);
  assert.deepEqual([a.paperW, a.paperH, a.originX, a.originY, a.width, a.height, a.cols, a.rows], [210, 297, 17.5, 283.8, 175, 270.6, 20, 19]);
  assert.deepEqual(a.sheet, { minX: 10, maxX: 200, minY: 10, maxY: 287 }, 'the margin line itself does not move');
  const l = B.paperArea({ w: 210, h: 297, orientation: 'landscape', margin: 10 }, s);
  assert.deepEqual([l.paperW, l.paperH, l.originY, l.cols, l.rows], [297, 210, 196.8, 30, 13]);
  const g = B.geometry({ ...s, originX: a.originX, originY: a.originY, width: a.width, height: a.height });
  assert.deepEqual([g.cols, g.rows], [a.cols, a.rows]);
});

test('paper size: every listed size works, every dot stays 2 mm inside the margin line', () => {
  const rad = B.dotRadius(s), min = 10 + B.EDGE_GAP + rad - 1e-6;   // centre of a dot whose edge is 2 mm inside
  assert.equal(B.EDGE_GAP, 2);
  assert.equal(rad, 1.2);
  for (const p of B.PAPER_SIZES.filter(p => p.id !== 'custom')) {
    for (const orientation of ['portrait', 'landscape']) {
      const a = B.paperArea({ w: p.w, h: p.h, orientation, margin: 10 }, s);
      const set = { ...s, originX: a.originX, originY: a.originY, width: a.width, height: a.height };
      const r = B.layout('Braille for everyone 123. '.repeat(40), set);
      let top = -Infinity;
      for (const page of r.pages) for (const pt of B.points(page, set)) {
        assert.ok(pt.x >= min && pt.x <= a.paperW - min, p.id + ' x ' + pt.x);
        assert.ok(pt.y >= min && pt.y <= a.paperH - min, p.id + ' y ' + pt.y);
        top = Math.max(top, pt.y);
      }
      assert.ok(Math.abs(top + rad - (a.paperH - 10 - 2)) < 1e-6, `${p.id} ${orientation}: the top row starts exactly 2 mm under the margin line`);
    }
  }
});

test('paper size: inverted print is an exact left-right flip of the sheet', () => {
  const a = B.paperArea({ w: 215.9, h: 279.4, orientation: 'portrait', margin: 12 }, s);
  const set = { ...s, originX: a.originX, originY: a.originY, width: a.width, height: a.height };
  const r = B.layout('Hello world, letter paper.', set);
  const normal = B.points(r.pages[0], set).map(p => `${Math.round(p.x * 1000)},${p.y}`).sort();
  const flipped = B.pagePoints(r.pages[0], set, { invert: true }).map(p => `${Math.round((a.paperW - p.x) * 1000)},${p.y}`).sort();
  assert.deepEqual(flipped, normal);
});

test('paper size: bad input is explained', () => {
  assert.throws(() => B.paperArea({ w: 100, h: 100, orientation: 'portrait', margin: 49 }, s), /margin is too big/);
  assert.throws(() => B.paperArea({ w: 0, h: 100, orientation: 'portrait', margin: 5 }, s), /width and height/);
  assert.throws(() => B.paperArea({ w: 100, h: 100, orientation: 'portrait', margin: -1 }, s), /margin/);
  const c = B.paperArea({ w: 120, h: 80, orientation: 'portrait', margin: 5 }, s);
  assert.equal(c.paperW, 80, 'portrait puts the short side across');
});

const A4 = { w: 210, h: 297, orientation: 'portrait', margin: 10 };
const sheets = (text, pct) => B.layout(text, B.pageSettings(A4, s, pct)).pages.length;
const FOX = 'The quick brown fox jumps over the lazy dog. '.repeat(10);

test('page scaling: pitches scale, start position and area come from the paper', () => {
  const half = B.scalePitches(s, 50);
  assert.equal(half.dotPitch, 2); assert.equal(half.cellPitch, 4.5); assert.equal(half.linePitch, 7);
  assert.equal(half.feed, s.feed);
  const p100 = B.pageSettings(A4, s, 100), a = B.paperArea(A4, s);
  assert.equal(p100.originX, a.originX); assert.equal(p100.width, a.width); assert.equal(p100.originY, 283.8);
  // bigger braille, bigger dots: still 2 mm from the line to the dot's edge
  const p200 = B.pageSettings(A4, s, 200);
  assert.equal(p200.originY + B.dotRadius(p200), 287 - 2);
  const g50 = B.geometry(B.pageSettings(A4, s, 50)), g100 = B.geometry(p100);
  assert.ok(g50.cols > g100.cols && g50.rows > g100.rows);
});

test('page scaling: fit grows short text, reduce keeps 100 %, nothing to fit stays 100 %', () => {
  assert.deepEqual(B.fitScale('HELLO', s, A4, 'fit'), { pct: 200, fits: true });
  assert.deepEqual(B.fitScale('HELLO', s, A4, 'reduce'), { pct: 100, fits: true });
  assert.deepEqual(B.fitScale('', s, A4, 'fit'), { pct: 100, fits: true });
  assert.deepEqual(B.fitScale(' [[PAGE]] ', s, A4, 'fit'), { pct: 100, fits: true });
});

test('page scaling: fit and reduce pick the largest size that fits one sheet', () => {
  assert.ok(sheets(FOX, 100) > 1, 'needs more than one sheet at 100 %');
  for (const mode of ['fit', 'reduce']) {
    const f = B.fitScale(FOX, s, A4, mode);
    assert.ok(f.fits && f.pct < 100 && f.pct >= B.SCALE_MIN, mode + ' ' + f.pct);
    assert.equal(sheets(FOX, f.pct), 1);
    assert.ok(sheets(FOX, f.pct + 1) > 1, 'one percent bigger no longer fits');
  }
});

test('page scaling: too long even at the smallest size; every page of a multi-page text fits', () => {
  assert.deepEqual(B.fitScale('word '.repeat(3000), s, A4, 'fit'), { pct: B.SCALE_MIN, fits: false });
  const text = ['one short page', FOX, 'third'].join('[[PAGE]]');
  const f = B.fitScale(text, s, A4, 'fit');
  assert.ok(f.fits);
  assert.equal(sheets(text, f.pct), 3, 'each page fits one sheet');
  assert.ok(sheets(text, f.pct + 1) > 3);
});

test('page scaling: never outside the page (every paper, both orientations, fit / reduce / custom, invert on and off)', () => {
  const texts = ['HELLO', FOX, 'word '.repeat(300), ['a b c', FOX, '123 456 7890'].join('[[PAGE]]')];
  let checked = 0, refused = 0;
  for (const p of [...B.PAPER_SIZES.filter(x => x.id !== 'custom'), { id: 'card 30 x 30', w: 30, h: 30 }]) for (const orientation of ['portrait', 'landscape']) for (const margin of [0, 10]) {
    const paper = { w: p.w, h: p.h, orientation, margin };
    for (const text of texts) {
      for (const pct of [B.fitScale(text, s, paper, 'fit').pct, B.fitScale(text, s, paper, 'reduce').pct, 50, 137, 200]) {
        let set;
        try { set = B.pageSettings(paper, s, pct); } catch (_) { refused++; continue; }   // too big for this paper: refused, never printed
        const sheet = B.paperArea(paper, B.scalePitches(s, pct)).sheet;
        const inner = { minX: sheet.minX + B.EDGE_GAP, maxX: sheet.maxX - B.EDGE_GAP, minY: sheet.minY + B.EDGE_GAP, maxY: sheet.maxY - B.EDGE_GAP };
        for (const page of B.layout(text, set).pages) for (const invert of [false, true]) {
          const pts = B.pagePoints(page, set, { invert });
          assert.equal(B.offSheet(pts, sheet, B.dotRadius(set)), 0, `${p.id} ${orientation} margin ${margin} at ${pct} %`);
          assert.equal(B.offSheet(pts, inner, B.dotRadius(set)), 0, `2 mm gap: ${p.id} ${orientation} margin ${margin} at ${pct} %`);
          checked++;
        }
      }
    }
  }
  assert.ok(checked > 1000 && refused > 0, `${checked} pages checked, ${refused} too-big sizes refused`);
  assert.equal(B.offSheet([{ x: 9, y: 50 }, { x: 50, y: 50 }, { x: 50, y: 288 }], { minX: 10, maxX: 200, minY: 10, maxY: 287 }), 2, 'dots past the margins are caught');
  assert.equal(B.offSheet([{ x: 11, y: 50 }, { x: 50, y: 286 }, { x: 50, y: 50 }], { minX: 10, maxX: 200, minY: 10, maxY: 287 }, 1.2), 2, 'a dot whose edge crosses the line is caught');
});

test('page scaling: a very long text is quick to size', () => {
  const t = Date.now();
  assert.deepEqual(B.fitScale('word '.repeat(199000), s, A4, 'fit'), { pct: B.SCALE_MIN, fits: false });
  assert.ok(Date.now() - t < 1500, (Date.now() - t) + ' ms');
});

test('page scaling: settings errors are reported, a small card limits the size', () => {
  assert.throws(() => B.fitScale('hi', { ...s, feed: 0 }, A4, 'fit'), /Plunge feed/);
  const card = { w: 30, h: 30, orientation: 'portrait', margin: 5 };
  assert.deepEqual(B.fitScale('hi', s, card, 'fit'), { pct: 103, fits: true });
  assert.equal(B.layout('hi', B.pageSettings(card, s, 103)).pages.length, 1);
  assert.throws(() => B.pageSettings(card, s, 104), /margin is too big/);
});


// ---------------------------------------------------------------- Bangla braille
const bn = (w, o) => B.cellsFor(w, o).map(c => c.dots.join('')).join(' ');
test('Bangla: letters, vowel signs and signs (Bangladesh)', () => {
  assert.equal(bn('বাংলা'), '12 345 56 123 345');
  assert.equal(bn('কি'), '13 24');
  assert.equal(bn('চাঁদ'), '14 345 3 145');
  assert.equal(bn('দুঃখ'), '145 136 6 1346');
  assert.equal(bn('খাবার'), '1346 345 12 345 1235');
  assert.equal(bn('ঝড়'), '1356 12456');
  assert.equal(bn('ভাই'), '1236 345 24');
  assert.equal(bn('উৎসব'), '136 5 2345 234 12');
  assert.equal(bn('ঢ়'), '12356');
  assert.equal(bn('য়'), '26');
  assert.equal(bn('ঋতু'), '5 1235 2345 136');
  assert.equal(bn('কৃষক'), '13 5 1235 12346 13');
});

test('Bangla: India (Bharati) letters', () => {
  const o = { bangla: 'in' };
  assert.equal(bn('খাবার', o), '46 345 12 345 1235');
  assert.equal(bn('ঝড়', o), '356 12456');
  assert.equal(bn('ভাই', o), '45 345 24');
  assert.equal(bn('উৎসব', o), '136 4 2345 234 12');
  assert.equal(bn('ঢ়', o), '5 12456');
  assert.equal(bn('বাংলা', o), bn('বাংলা'), 'the rest is the same');
});

test('Bangla: halant before the consonant, ksha and jña, inherent a before a vowel letter', () => {
  assert.equal(bn('ধর্ম'), '2346 4 1235 134', 'Standard Bharati Braille example (धर्म)');
  assert.equal(bn('কর্ম'), '13 4 1235 134');
  assert.equal(bn('ব্যাংক'), '4 12 13456 345 56 13');
  assert.equal(bn('রাষ্ট্র'), '1235 345 4 12346 4 23456 1235');
  assert.equal(bn('ক্ষমা'), '12345 134 345');
  assert.equal(bn('জ্ঞান'), '156 345 1345');
  assert.equal(bn('কই'), '13 1 24', 'কই: explicit a, not কি');
  assert.notEqual(bn('কই'), bn('কি'));
});

test('Bangla: digits, letter sign after a number, danda, nukta and NFC forms', () => {
  assert.equal(bn('২০২৬'), '3456 12 245 12 124');
  assert.equal(bn('৫ই'), '3456 15 56 24', 'a letter right after a number takes the letter sign');
  assert.equal(bn('১২বার'), '3456 1 12 56 12 345 1235');
  assert.equal(bn('।'), '256');
  assert.equal(bn('বড়'), bn('বড়'), 'ড় precomposed and decomposed');
  const r = B.layout('ভালো আছি।', s);
  assert.deepEqual(r.unsupported, []);
  assert.equal(B.lineText(r.pages[0][0]), 'ভালো আছি।', 'ে + া typed separately becomes ো');
  const odd = B.layout('দাম ৳৫০', s);
  assert.deepEqual(odd.unsupported.map(u => u.ch), ['৳']);
});

test('Bangla: pages, invert and ASCII-only G-code comments', () => {
  const text = 'আমার সোনার বাংলা, আমি তোমায় ভালোবাসি। ১৯৭১ সালে স্বাধীনতা।';
  const r = B.layout(text, s);
  assert.deepEqual(r.unsupported, []);
  const code = B.gcode(r.pages[0], r.settings, 0, 1, { invert: true });
  assert.ok(!/[^\x00-\x7f]/.test(code), 'G-code is plain ASCII');
  assert.ok(code.includes('; TEXT: AAMAARA SONAARA BAANGLAA'), code.split('\n').find(l => l.includes('TEXT')));
  assert.ok(code.includes('; ===== HALANT ====='));
  const normal = B.points(r.pages[0], r.settings).length;
  assert.equal(B.pagePoints(r.pages[0], r.settings, { invert: true }).length, normal);
});

test('photo orientation (EXIF) from JPEG files', () => {
  const exif = (le, value, extra = '') => {
    const tiff = le
      ? '49492a0008000000' + '0200' + '0f01020004000000' + '41424300' + '1201030001000000' + value.toString(16).padStart(2, '0') + '00' + '0000' + '00000000'
      : '4d4d002a00000008' + '0002' + '010f000200000004' + '41424300' + '0112000300000001' + value.toString(16).padStart(4, '0') + '0000' + '00000000';
    const body = '457869660000' + tiff;
    const len = (body.length / 2 + 2).toString(16).padStart(4, '0');
    return Buffer.from('ffd8' + extra + 'ffe1' + len + body + 'ffdb0004abcd' + 'ffda000c', 'hex');
  };
  assert.equal(B.jpegOrientation(exif(true, 6)), 6, 'little endian (Android, most cameras)');
  assert.equal(B.jpegOrientation(exif(false, 8)), 8, 'big endian (iPhone)');
  assert.equal(B.jpegOrientation(exif(true, 3, 'ffe000104a46494600010100000100010000')), 3, 'after a JFIF segment');
  assert.equal(B.jpegOrientation(exif(true, 1)), 1);
  assert.equal(B.jpegOrientation(exif(true, 9)), 1, 'nonsense value');
  assert.equal(B.jpegOrientation(Buffer.from('ffd8ffe000104a46494600010100000100010000ffda000c', 'hex')), 1, 'no EXIF');
  assert.equal(B.jpegOrientation(Buffer.from('89504e470d0a1a0a', 'hex')), 1, 'not a JPEG');
  assert.equal(B.jpegOrientation(exif(true, 6).subarray(0, 30)), 1, 'cut short');
  assert.equal(B.jpegOrientation(new Uint8Array(0)), 1);
});

console.log(`PASS core: ${passed} tests`);
