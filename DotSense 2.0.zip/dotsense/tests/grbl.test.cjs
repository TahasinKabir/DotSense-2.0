// DotSense machine link tests against the GRBL simulator: node tests/grbl.test.cjs
const assert = require('node:assert/strict');
const { GrblLink, parseStatus } = require('../grbl');
const { FakeGrbl } = require('../fake-grbl');
const B = require('../core');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const log = {};
const until = async (fn, ms = 10000, what = 'condition') => {
  const t = Date.now();
  while (!fn()) { if (Date.now() - t > ms) throw new Error('Timed out waiting for ' + what); await sleep(5); }
};

function makeJob(text, over = {}) {
  const s = { ...B.DEFAULTS, ...over };
  const r = B.layout(text, s);
  const j = B.jobLines(r.pages[0], r.settings, 0, 1);
  return { lines: j.lines, points: j.points, clearZ: r.settings.clearZ, estimate: 10, page: 0, pages: 1 };
}

async function connect(opts = {}) {
  const fake = new FakeGrbl(Object.assign({ timeScale: 40 }, opts));
  const link = new GrblLink({ pollMs: 20, bannerTimeout: 800 });
  const events = [];
  link.on('job', e => events.push(e));
  const progress = [];
  link.on('progress', p => progress.push(p));
  await link.open(fake);
  return { fake, link, events, progress };
}

const tests = [];
const test = (name, fn) => tests.push([name, fn]);

test('Check (auto calibrate): up 5 mm, round the margin, back to the start at clearance; jog cancel stops it', async () => {
  const { fake, link } = await connect();
  await until(() => /^Idle/.test(link.state), 2000, 'Idle');
  const path = [[10, 135], [170, 135], [170, 15], [10, 15], [10, 135], [10, 135]];
  const sent = [];
  const write = link.writeRaw.bind(link);
  link.writeRaw = s => { sent.push(s); write(s); };
  const seen = [];
  const watch = setInterval(() => seen.push(fake.mpos.slice()), 5);
  await link.frame(path, { lift: 5, feed: 2000, endZ: 5 });
  clearInterval(watch);
  const lines = sent.join('').replace(/[?!~\x18\x85]/g, '').split('\n').filter(Boolean);   // (without the status polls)
  assert.deepEqual(lines.filter(l => l.startsWith('$J=')), ['$J=G21 G91 Z5 F300', '$J=G21 G90 X10 Y135 F2000', '$J=G21 G90 X170 Y135 F2000',
    '$J=G21 G90 X170 Y15 F2000', '$J=G21 G90 X10 Y15 F2000', '$J=G21 G90 X10 Y135 F2000', '$J=G21 G90 X10 Y135 F2000', '$J=G21 G90 Z5 F300']);
  assert.ok(/^Idle/.test(link.state), 'waited until the moves were done');
  assert.deepEqual(fake.mpos.map(v => Math.round(v * 1000) / 1000), [10, 135, 5]);
  assert.ok(Math.max(...seen.map(p => p[0])) > 150 && Math.min(...seen.map(p => p[1])) < 35, 'went round the far corner');
  assert.ok(Math.max(...seen.map(p => p[2])) <= 5.001 && seen.some(p => p[2] > 4.99), 'up 5 mm (from Z 0)');
  // stopped on the way: jog cancel, Idle, not at the start
  const run = link.frame(path, { lift: 5, feed: 2000, endZ: 5 });
  await until(() => /^Jog/.test(link.state), 2000, 'moving');
  await sleep(30);
  link.realtime('jogCancel');
  await run;
  assert.ok(/^Idle/.test(link.state));
  assert.ok(!(Math.abs(fake.mpos[0] - 10) < 0.01 && Math.abs(fake.mpos[1] - 135) < 0.01), 'stopped where it was');
  await assert.rejects(link.frame([[1, 2]], { lift: 50, feed: 2000, endZ: 5 }), /Invalid check path/);
  await link.close();
  fake.close();
});

test('parses GRBL 1.1 and 0.9 status reports', async () => {
  const a = parseStatus('<Run|MPos:1.000,2.500,-3.000|FS:500,0|Ln:42|WCO:0.000,1.000,0.000>');
  assert.equal(a.state, 'Run'); assert.deepEqual(a.mpos, [1, 2.5, -3]); assert.equal(a.ln, 42); assert.deepEqual(a.wco, [0, 1, 0]);
  const b = parseStatus('<Hold:0|WPos:5.000,6.000,7.000|Bf:15,128|FS:0,0>');
  assert.equal(b.state, 'Hold:0'); assert.deepEqual(b.wpos, [5, 6, 7]); assert.deepEqual(b.bf, [15, 128]);
  const c = parseStatus('<Idle,MPos:1.000,2.000,3.000,WPos:0.500,1.000,1.500>');
  assert.equal(c.state, 'Idle'); assert.deepEqual(c.mpos, [1, 2, 3]); assert.deepEqual(c.wpos, [0.5, 1, 1.5]);
});

test('connects, reads settings and machine rates', async () => {
  const { fake, link } = await connect();
  assert.equal(link.connected, true);
  assert.equal(link.version, '1.1h');
  assert.equal(link.info().rates.rateXY, 1000);
  await until(() => /^Idle/.test(link.state), 2000, 'Idle');
  await link.close();
  assert.equal(link.connected, false);
  fake.close();
});

test('connect sends soft reset when the board does not reset on open', async () => {
  const fake = new FakeGrbl({ banner: false, timeScale: 40 });
  const link = new GrblLink({ pollMs: 20, bannerTimeout: 300 });
  await link.open(fake);
  assert.equal(link.version, '1.1h');
  await link.close();
});

test('connect fails clearly when nothing answers', async () => {
  const { EventEmitter } = require('events');
  const silent = Object.assign(new EventEmitter(), { write() {}, close(cb) { cb && cb(); } });
  const link = new GrblLink({ pollMs: 20, bannerTimeout: 150 });
  await assert.rejects(link.open(silent), /No reply from GRBL/);
  await link.close();
});

test('streams a page: every dot punched, no buffer overflow, live progress reaches 100%', async () => {
  const { fake, link, events, progress } = await connect();
  const job = makeJob('hello 12');
  link.startJob(job);
  await until(() => events.some(e => e.type === 'done'), 60000, 'done');
  assert.equal(fake.overflow, false, 'serial buffer overflow');
  assert.ok(fake.maxRx <= 127);
  assert.deepEqual(fake.punches.map(p => [p.x, p.y]), job.points.map(p => [p.x, p.y]));
  const done = events.find(e => e.type === 'done');
  assert.equal(done.dotsDone, job.points.length);
  assert.equal(done.percent, 100);
  // progress never goes backwards and walks through the dots
  for (let i = 1; i < progress.length; i++) assert.ok(progress[i].dotsDone >= progress[i - 1].dotsDone);
  const seen = new Set(progress.map(p => p.current));
  assert.ok(seen.size > job.points.length / 2, 'live progress should visit most dots, saw ' + seen.size);
  assert.ok(progress.some(p => p.phase === 'punch'));
  assert.ok(!fake.received.some(l => l.includes('%') || l.includes(';')));
  assert.deepEqual(fake.workPos().slice(0, 2), [0, 0]); // returned to X0 Y0 like the original app
  await link.close(); fake.close();
});

test('pause holds the machine and resume finishes the page', async () => {
  const { fake, link, events } = await connect({ timeScale: 20 });
  const job = makeJob('abcdef');
  link.startJob(job);
  await until(() => fake.punches.length >= 3, 20000, '3 punches');
  assert.equal(link.pauseJob(), true);
  await until(() => link.state === 'Hold:0', 3000, 'Hold:0');
  const n = fake.punches.length;
  await sleep(300);
  assert.equal(fake.punches.length, n, 'no punches while paused');
  assert.equal(link.resumeJob(), true);
  await until(() => events.some(e => e.type === 'done'), 60000, 'done');
  assert.equal(fake.punches.length, job.points.length);
  await link.close(); fake.close();
});

test('stop: hold, reset without alarm, punch lifted to clearance', async () => {
  const { fake, link, events } = await connect({ timeScale: 10 });
  const job = makeJob('stop test words');
  link.startJob(job);
  await until(() => fake.punches.length >= 2 && fake.workPos()[2] < 0, 20000, 'mid punch');
  await link.stopJob();
  const stopped = events.find(e => e.type === 'stopped');
  assert.ok(stopped, 'stopped event');
  assert.equal(stopped.held, true);
  assert.equal(stopped.reset, true);
  await until(() => Math.abs(fake.workPos()[2] - 5) < 1e-6 && fake.state === 'Idle', 5000, 'Z at clearance');
  assert.notEqual(link.state, 'Alarm');
  assert.ok(fake.punches.length < job.points.length);
  assert.equal(link.job, null);
  await link.close(); fake.close();
});

test('soft reset (Ctrl-X) aborts a running job at once and the machine answers again', async () => {
  const { fake, link, events } = await connect({ timeScale: 10 });
  const job = makeJob('soft reset abort test');
  link.startJob(job);
  await until(() => fake.punches.length >= 2, 20000, 'two punches');
  await link.softReset();
  const aborted = events.find(e => e.type === 'aborted');
  assert.ok(aborted, 'aborted event');
  assert.equal(aborted.reset, true);
  assert.ok(!events.some(e => e.type === 'reset'), 'not reported as an unexpected reset');
  assert.equal(link.job, null);
  const n = fake.punches.length;
  await sleep(300);
  assert.equal(fake.punches.length, n, 'nothing punched after the reset');
  assert.ok(n < job.points.length);
  const seq = link.statusSeq;
  await until(() => link.statusSeq > seq, 3000, 'status after the reset');
  log.alarmAfterAbort = link.state;
  if (/^Alarm/.test(link.state) || link.alarmPending) await link.unlock();   // reset while moving: GRBL asks for $X
  await link.command('G91 G0 Z1', { timeout: 3000 });   // accepts commands again
  await link.command('G90', { timeout: 3000 });
  await link.softReset();                              // also without a job
  await link.close(); fake.close();
});

test('check mode ($C): the page is checked, nothing moves, errors still show, off resets GRBL', async () => {
  const { fake, link, events } = await connect({ failLine: 0 });
  await until(() => /^Idle/.test(link.state), 2000, 'Idle');
  assert.equal(await link.toggleCheckMode(), true);
  assert.equal(link.state, 'Check');
  const job = makeJob('check me please');
  link.startJob(job);
  await until(() => events.some(e => e.type === 'done'), 10000, 'check finished');
  assert.equal(fake.punches.length, 0, 'nothing punched');
  assert.deepEqual(fake.mpos, [0, 0, 0], 'nothing moved');
  assert.ok(fake.gcodeLines > job.points.length * 3, 'every line was read');
  await assert.rejects(link.jog('X', 1, 500), /error:8/, 'no jogging in check mode');
  assert.equal(await link.toggleCheckMode(), false);
  assert.ok(/^Idle/.test(link.state));
  await link.close(); fake.close();
  // a bad line is still reported in check mode
  const b = await connect({ failLine: 12 });
  await until(() => /^Idle/.test(b.link.state), 2000, 'Idle');
  await b.link.toggleCheckMode();
  b.link.startJob(makeJob('ab'));
  await until(() => b.events.some(e => e.type === 'error'), 10000, 'error in check mode');
  assert.equal(b.fake.punches.length, 0);
  await b.link.stopJob();
  await sleep(200);
  assert.deepEqual(b.fake.mpos, [0, 0, 0], 'Stop after a check does not lift or move anything');
  await b.link.close(); b.fake.close();
});

test('G-code error holds the job; resume continues', async () => {
  const { fake, link, events } = await connect({ failLine: 12 });
  link.startJob(makeJob('ab'));
  await until(() => events.some(e => e.type === 'error'), 10000, 'error');
  const err = events.find(e => e.type === 'error');
  assert.equal(err.code, '20');
  assert.equal(link.job.state, 'error');
  link.resumeJob();
  await until(() => events.some(e => e.type === 'done'), 20000, 'done');
  await link.close(); fake.close();
});

test('alarm ends the job', async () => {
  const { fake, link, events } = await connect({ alarmAfterLines: 20 });
  link.startJob(makeJob('alarm test'));
  await until(() => events.some(e => e.type === 'alarm'), 10000, 'alarm');
  assert.equal(link.job, null);
  assert.equal(link.state, 'Alarm');
  await assert.rejects(() => Promise.resolve().then(() => link.startJob(makeJob('x'))), /ALARM/);
  await assert.rejects(link.command('G0 X1'), /Unlock/);
  await link.unlock();
  await until(() => link.state === 'Idle', 3000, 'Idle after unlock');
  link.startJob(makeJob('x'));
  await until(() => events.some(e => e.type === 'done'), 20000, 'done after unlock');
  await link.close(); fake.close();
});

test('USB unplug during print is reported', async () => {
  const { fake, link, events } = await connect({ timeScale: 5 });
  link.startJob(makeJob('unplug'));
  await until(() => fake.punches.length >= 1, 20000, 'punch');
  fake.close();
  await until(() => events.some(e => e.type === 'disconnected'), 3000, 'disconnected');
  assert.equal(link.connected, false);
});

test('progress without line numbers uses dwell sync points', async () => {
  const { fake, link, events, progress } = await connect({ reportLn: false });
  const job = makeJob('sync');
  link.startJob(job);
  await until(() => events.some(e => e.type === 'done'), 30000, 'done');
  for (let i = 1; i < progress.length; i++) assert.ok(progress[i].dotsDone >= progress[i - 1].dotsDone);
  assert.ok(new Set(progress.map(p => p.dotsDone)).size > job.points.length / 2);
  assert.equal(progress.some(p => p.approx), false);
  await link.close(); fake.close();
});

test('GRBL 0.9 firmware works (status format, jog fallback)', async () => {
  const { fake, link, events } = await connect({ version: '0.9j' });
  await until(() => /^Idle/.test(link.state), 2000, 'Idle');
  await link.jog('X', 5, 500);
  await until(() => Math.abs(fake.workPos()[0] - 5) < 1e-6, 5000, 'jogged');
  link.startJob(makeJob('ok'));
  await until(() => events.some(e => e.type === 'done'), 30000, 'done');
  await link.close(); fake.close();
});

test('jog, set zero and command rules', async () => {
  const { fake, link } = await connect();
  await link.jog('X', 12.5, 1000);
  await link.jog('Y', -3, 1000);
  await until(() => fake.state === 'Idle' && Math.abs(fake.mpos[0] - 12.5) < 1e-6, 5000, 'jog done');
  await link.command('G10 L20 P1 X0 Y0');
  assert.deepEqual(fake.workPos().slice(0, 2), [0, 0]);
  await assert.rejects(link.command('G0 X1\nG0 X2'), /Invalid/);
  await until(() => /^Idle/.test(link.state), 2000, 'Idle');
  link.startJob(makeJob('a'));
  await assert.rejects(link.command('$X'), /Printing/);
  assert.throws(() => link.startJob(makeJob('a')), /Already printing/);
  await link.stopJob();
  await link.close(); fake.close();
});

test('refuses unexpected commands inside a print job', async () => {
  const { fake, link } = await connect();
  await until(() => /^Idle/.test(link.state), 2000, 'Idle');
  assert.throws(() => link.startJob({ lines: [{ code: '$H' }] }), /Refusing/);
  assert.throws(() => link.startJob({ lines: [] }), /Nothing/);
  await link.close(); fake.close();
});

(async () => {
  let n = 0;
  for (const [name, fn] of tests) {
    const t = Date.now();
    try { await fn(); n++; console.log('  ok  ' + name + ' (' + (Date.now() - t) + 'ms)'); }
    catch (e) { console.error('FAIL ' + name + '\n', e); process.exit(1); }
  }
  console.log('PASS grbl: ' + n + ' tests');
  process.exit(0);
})();
