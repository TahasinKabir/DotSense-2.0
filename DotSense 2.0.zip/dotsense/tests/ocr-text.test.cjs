// DotSense OCR text tests: node tests/ocr-text.test.cjs
const assert = require('node:assert/strict');
const T = require('../ocr-text');
let passed = 0;
const test = (name, fn) => { fn(); passed++; };

// a line of words as the engine gives them: [text, confidence] pairs laid out left to right
function line(y, pairs, opts = {}) {
  let x = opts.x || 100;
  const h = opts.h || 40, gap = opts.gap || 18;
  const words = pairs.map(([text, conf, extra]) => {
    const w = Math.max(20, [...text].length * 22);
    if (extra) x += extra;
    const word = { text, conf, bbox: { x0: x, y0: y, x1: x + w, y1: y + h } };
    x += w + gap;
    return word;
  });
  const x1 = words[words.length - 1].bbox.x1;
  return { bbox: { x0: words[0].bbox.x0, y0: y, x1, y1: y + h }, baseline: { x0: words[0].bbox.x0, y0: y + h - 8, x1, y1: y + h - 8 }, block: opts.block || 0, words };
}
const hi = t => [t, 95];

test('a Bangla line: Latin words the engine doubts are read again in Bangla', () => {
  const lines = [line(100, [hi('বাংলাদেশ'), ['SHEE', 40], hi('সুন্দর'), hi('দেশ।')])];
  assert.equal(T.needsBanglaLook(lines), true);
  assert.equal(T.needsEnglishLook(lines), false);
  const w = lines[0].words[1];
  const bangla = [{ words: [{ text: 'একটি', conf: 80, bbox: { x0: w.bbox.x0 + 5, y0: 100, x1: w.bbox.x1 - 5, y1: 140 } }] }];
  assert.equal(T.buildText(lines, { bangla }), 'বাংলাদেশ একটি সুন্দর দেশ।');
  // real English words in a Bangla line are sure of themselves: they stay
  const mixed = [line(100, [hi('আমি'), ['DotSense', 90], hi('দিয়ে'), ['USB', 96], hi('প্রিন্ট')])];
  assert.equal(T.needsBanglaLook(mixed), false);
  assert.equal(T.buildText(mixed), 'আমি DotSense দিয়ে USB প্রিন্ট');
});

test('an English line: a stray Bangla digit or a doubted number is read again in English', () => {
  const lines = [line(100, [hi('Reading'), hi('is'), ['৭', 82], hi('right,'), ['9310', 84], hi('the'), hi('teacher.')])];
  assert.equal(T.needsEnglishLook(lines), true);
  const at = k => lines[0].words[k].bbox;
  const english = [{ words: [{ text: 'a', conf: 90, bbox: at(2) }, { text: 'said', conf: 90, bbox: at(4) }] }];
  assert.equal(T.buildText(lines, { english }), 'Reading is a right, said the teacher.');
  assert.equal(T.needsEnglishLook([line(100, [hi('In'), hi('1824'), hi('and'), ['250', 91]])]), false, 'real numbers stay');
});

test('junk from the edges of a photo goes', () => {
  const lines = [
    line(20, [['—————————', 0]]),
    line(100, [hi('The'), hi('Braille'), hi('system.')]),
    line(150, [['তটটটটটাামাঢঢর', 20], ['—', 30]]),
    line(200, [['EE', 0], ['———', 0], ['উই', 51]]),
    line(250, [hi('Blind'), hi('readers'), hi('read.'), ['|', 40, 500]])
  ];
  assert.equal(T.buildText(lines), 'The Braille system. Blind readers read.');
  assert.equal(T.junkWord({ text: '৮১৯॥|ক॥এ॥|০০০০০০০', conf: 10 }), true);
  assert.equal(T.junkWord({ text: '1,000', conf: 90 }), false);
  assert.equal(T.junkWord({ text: '—', conf: 20 }), false, 'a dash between words stays');
});

test('a danda read as | or l: right after a Bangla word it is the danda, at an edge it goes', () => {
  const lines = [line(100, [hi('আমি'), hi('ভালো'), hi('আছি'), ['|', 60], hi('তুমি'), hi('কেমন'), ['l', 55], ['|', 30, 400]])];
  assert.equal(T.buildText(lines), 'আমি ভালো আছি। তুমি কেমন।');
  assert.equal(T.buildText([line(100, [hi('আর'), hi('এটি'), ['|', 70], hi('SB'), hi('দিয়ে')])]), 'আর এটি SB দিয়ে', '| SB is USB, not a danda');
});

test('paragraphs: the lines of one are joined, more room or a new block starts the next', () => {
  const lines = [
    line(100, [hi('The'), hi('Braille'), hi('system'), hi('was'), hi('invented'), hi('by')]),
    line(160, [hi('Louis'), hi('Braille'), hi('in'), hi('1824.')]),
    line(250, [hi('Today'), hi('braille'), hi('is'), hi('used'), hi('all'), hi('over')]),
    line(310, [hi('the'), hi('world.')]),
    line(370, [hi('It'), hi('helps'), hi('many.')], { block: 1 })
  ];
  assert.equal(T.buildText(lines), 'The Braille system was invented by Louis Braille in 1824.\n\nToday braille is used all over the world.\n\nIt helps many.');
  assert.equal(T.buildText(lines, { keepLines: true }), 'The Braille system was invented by\nLouis Braille in 1824.\n\nToday braille is used all over\nthe world.\n\nIt helps many.');
  // a word broken at the end of a line is put together; a list keeps its lines
  const hyph = [line(100, [hi('the'), hi('infor-')]), line(160, [hi('mation'), hi('age')])];
  assert.equal(T.buildText(hyph), 'the information age');
  const list = [line(100, [hi('Things:')]), line(160, [hi('-'), hi('paper')]), line(220, [hi('-'), hi('punch')])];
  assert.equal(T.buildText(list), 'Things:\n- paper\n- punch');
});

test('paragraphs in a tilted photo: measured along the baselines', () => {
  // the page turned by 4 degrees: long lines' boxes are tall, short ones not
  const tilt = (y, pairs, len) => {
    const l = line(y, pairs);
    const s = -0.07, x0 = l.bbox.x0, x1 = x0 + len;
    l.baseline = { x0, y0: y + 32, x1, y1: y + 32 + s * len };
    l.bbox = { x0, x1, y0: Math.min(y, y + s * len), y1: y + 40 };
    return l;
  };
  const lines = [tilt(100, [hi('arranged'), hi('in'), hi('cells'), hi('of'), hi('six,')], 2800),
    tilt(225, [hi('and'), hi('each'), hi('cell'), hi('stands'), hi('for'), hi('a')], 2800),
    tilt(350, [hi('punctuation'), hi('mark.')], 700),
    tilt(540, [hi('Today'), hi('braille'), hi('is'), hi('used'), hi('everywhere')], 2800),
    tilt(665, [hi('in'), hi('the'), hi('world.')], 900)];
  assert.equal(T.buildText(lines), 'arranged in cells of six, and each cell stands for a punctuation mark.\n\nToday braille is used everywhere in the world.');
});

test('small repairs', () => {
  assert.equal(T.fixText('দেশ | এদেশের থাক৷ দরকার ।'), 'দেশ। এদেশের থাক। দরকার।');
  assert.equal(T.fixText('বাংলাদেশI সুন্দর'), 'বাংলাদেশ। সুন্দর');
  assert.equal(T.fixText('ি কথা বল'), 'কথা বল', 'a vowel sign without its letter');
  assert.equal(T.fixText('| am here , ok ?'), 'I am here, ok?');
  assert.equal(T.fixText('“ পরিশ্রম সৌভাগ্যের প্রসূতি। ” ১৯৭১'), '“পরিশ্রম সৌভাগ্যের প্রসূতি।” ১৯৭১');
  assert.equal(T.fixText('a  b\n\n\n\nc'), 'a b\n\nc');
  assert.equal(T.fixText('কোো'.normalize('NFD')), 'কোো'.normalize('NFC'), 'the same letters, composed');
});

test('nothing to read: nothing', () => {
  assert.equal(T.buildText([]), '');
  assert.equal(T.buildText(T.linesOf({ blocks: [] })), '');
  assert.equal(T.buildText(T.linesOf(null)), '');
});

console.log(`PASS ocr-text: ${passed} tests`);
