// Photo-from-phone server tests: node tests/phone.test.cjs
const assert = require('node:assert/strict');
const http = require('http');
const P = require('../phone-server');

const PNG = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8ffffff7f0009fb03fd2a86e38a0000000049454e44ae426082', 'hex');
const JPEG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(200, 7), Buffer.from([0xff, 0xd9])]);
const HEIC = Buffer.concat([Buffer.from([0, 0, 0, 0x18]), Buffer.from('ftypheic'), Buffer.alloc(40)]);

// ---- formats
assert.deepEqual(P.imageType(JPEG), { mime: 'image/jpeg', ext: 'jpg' });
assert.deepEqual(P.imageType(PNG), { mime: 'image/png', ext: 'png' });
assert.deepEqual(P.imageType(Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(4), Buffer.from('WEBPVP8 '), Buffer.alloc(20)])), { mime: 'image/webp', ext: 'webp' });
assert.deepEqual(P.imageType(Buffer.concat([Buffer.from('BM'), Buffer.alloc(60)])), { mime: 'image/bmp', ext: 'bmp' });
assert.equal(P.imageType(Buffer.from('<html>hello</html>')), null);
assert.equal(P.imageType(HEIC), null);
assert.equal(P.isHeic(HEIC), true);
assert.equal(P.isHeic(JPEG), false);

// ---- addresses: the WiFi one first; virtual adapters, loopback and "no address yet" left out
const ifaces = {
  'Loopback Pseudo-Interface 1': [{ address: '127.0.0.1', family: 'IPv4', internal: true }],
  Ethernet: [{ address: '192.168.1.20', family: 'IPv4', internal: false }],
  'vEthernet (WSL)': [{ address: '172.20.0.1', family: 'IPv4', internal: false }],
  'Wi-Fi': [{ address: 'fe80::1', family: 'IPv6', internal: false }, { address: '192.168.4.2', family: 'IPv4', internal: false }],
  'Bluetooth Network Connection': [{ address: '169.254.10.2', family: 'IPv4', internal: false }],
  'VirtualBox Host-Only Network': [{ address: '192.168.56.1', family: 'IPv4', internal: false }]
};
assert.deepEqual(P.addresses(ifaces), [
  { ip: '192.168.4.2', iface: 'Wi-Fi', wifi: true },
  { ip: '192.168.1.20', iface: 'Ethernet', wifi: false }
]);
assert.deepEqual(P.addresses({ wlp2s0: [{ address: '10.0.0.7', family: 4, internal: false }], docker0: [{ address: '172.17.0.1', family: 'IPv4', internal: false }] }), [{ ip: '10.0.0.7', iface: 'wlp2s0', wifi: true }]);
assert.deepEqual(P.addresses({ 'Wi-Fi': [{ address: '169.254.3.3', family: 'IPv4', internal: false }] }), [], 'no DHCP address yet');

// ---- phone names, WiFi code, QR code
assert.equal(P.deviceName('Mozilla/5.0 (Linux; Android 14; SM-A546E) AppleWebKit/537.36 Chrome/128 Mobile Safari/537.36'), 'Android phone');
assert.equal(P.deviceName('Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 Version/17.5 Mobile/15E148 Safari/604.1'), 'iPhone');
assert.equal(P.wifiQrText('MKS_DLC', '12345678'), 'WIFI:T:WPA;S:MKS_DLC;P:12345678;;');
assert.equal(P.wifiQrText('a;b,c:d"e\\', 'p;w'), 'WIFI:T:WPA;S:a\\;b\\,c\\:d\\"e\\\\;P:p\\;w;;');
assert.equal(P.wifiQrText('Open', ''), 'WIFI:T:nopass;S:Open;;');
const svg = P.qrSvg('http://192.168.4.2:8123/abcdefgh23');
assert.match(svg, /^<svg [^>]*viewBox="0 0 (\d+) \1"/);
assert.match(P.qrDataUrl('x'), /^data:image\/svg\+xml;base64,/);
assert.match(P.newToken(), P.TOKEN_RE);
assert.notEqual(P.newToken(), P.newToken());

function request(port, method, urlPath, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, method, path: urlPath, headers, agent: false }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    if (body && headers['transfer-encoding'] === 'chunked') {
      // sent in pieces, with no size up front
      let i = 0;
      const next = () => { if (i >= body.length) return req.end(); req.write(body.subarray(i, i + 700)); i += 700; setImmediate(next); };
      next();
    } else req.end(body);
  });
}

(async () => {
  const s = new P.PhoneServer({ token: 'abcdefgh23', ports: [0], maxBytes: 5000 });
  assert.equal(s.token, 'abcdefgh23', 'a saved link is kept');
  assert.notEqual(new P.PhoneServer({ token: 'BAD TOKEN!' }).token, 'BAD TOKEN!');
  const events = [];
  for (const t of ['visit', 'photo', 'rejected', 'receiving']) s.on(t, e => events.push([t, e]));
  const info = await s.start();
  assert.equal(info.running, true);
  const port = s.port;
  assert.ok(port > 0);
  assert.match(info.url || 'http://x:1/abcdefgh23', /\/abcdefgh23$/);

  // the page
  const page = await request(port, 'GET', '/abcdefgh23', null, { 'user-agent': 'Android' });
  assert.equal(page.status, 200);
  assert.match(page.body, /Take photo/);
  assert.ok(!page.body.includes('__NONCE__'));
  const nonce = /nonce="([^"]+)"/.exec(page.body)[1];
  assert.ok(page.headers['content-security-policy'].includes(`'nonce-${nonce}'`));
  assert.equal(page.headers['cache-control'], 'no-store');
  assert.deepEqual(events.shift(), ['visit', { device: 'Android phone' }]);
  assert.equal((await request(port, 'GET', '/abcdefgh23/')).status, 200);
  events.length = 0;

  // wrong or missing link
  for (const p of ['/', '/abcdefgh24', '/abcdefgh2', '/abcdefgh23/../x', '/abcdefgh23/photo/x', '/x/photo']) {
    assert.equal((await request(port, 'GET', p)).status, 404, p);
  }
  assert.equal((await request(port, 'POST', '/wrongtoken1/photo', PNG)).status, 404);
  assert.equal((await request(port, 'GET', '/favicon.ico')).status, 204);
  assert.equal((await request(port, 'GET', '/abcdefgh23/photo')).status, 405);

  // ping
  const ping = await request(port, 'GET', '/abcdefgh23/ping', null, { 'user-agent': 'iPhone' });
  assert.deepEqual(JSON.parse(ping.body), { ok: true, app: 'DotSense' });
  assert.deepEqual(events.shift(), ['visit', { device: 'iPhone' }]);

  // photos
  const up = await request(port, 'POST', '/abcdefgh23/photo', PNG, { 'content-type': 'image/png' });
  assert.equal(up.status, 200);
  assert.deepEqual(JSON.parse(up.body), { ok: true, n: 1 });
  const photo = events.find(e => e[0] === 'photo')[1];
  assert.equal(photo.name, 'phone-photo-1.png');
  assert.equal(photo.mime, 'image/png');
  assert.deepEqual(photo.bytes, PNG);
  events.length = 0;
  const up2 = await request(port, 'POST', '/abcdefgh23/photo', JPEG, { 'content-type': 'application/octet-stream', 'transfer-encoding': 'chunked' });
  assert.equal(up2.status, 200);
  assert.equal(events.find(e => e[0] === 'photo')[1].name, 'phone-photo-2.jpg', 'the file type comes from the bytes');
  events.length = 0;

  // refused: not an image, HEIC, too big (with and without a size up front)
  const text = await request(port, 'POST', '/abcdefgh23/photo', Buffer.from('#!/bin/sh\necho hi\n'), { 'content-type': 'image/jpeg' });
  assert.equal(text.status, 415);
  assert.match(JSON.parse(text.body).error, /not a photo/);
  const heic = await request(port, 'POST', '/abcdefgh23/photo', HEIC);
  assert.equal(heic.status, 415);
  assert.match(JSON.parse(heic.body).error, /HEIC/);
  const big = Buffer.concat([JPEG, Buffer.alloc(6000)]);
  const tooBig = await request(port, 'POST', '/abcdefgh23/photo', big);
  assert.equal(tooBig.status, 413);
  const tooBigChunked = await request(port, 'POST', '/abcdefgh23/photo', big, { 'transfer-encoding': 'chunked' }).catch(e => ({ status: 'reset', e }));
  assert.ok(tooBigChunked.status === 413 || tooBigChunked.status === 'reset', 'stopped while sending: ' + tooBigChunked.status);
  assert.ok(!events.some(e => e[0] === 'photo'), 'nothing refused reaches the app');
  assert.ok(events.filter(e => e[0] === 'rejected').length >= 3);
  assert.equal(s.uploads, 0, 'no upload left hanging');
  const after = await request(port, 'POST', '/abcdefgh23/photo', PNG);
  assert.equal(after.status, 200, 'still works after refusing');

  s.stop();
  assert.equal(s.running, false);
  assert.equal(s.info().url, '');
  await assert.rejects(request(port, 'GET', '/abcdefgh23'), /ECONNREFUSED|ECONNRESET/);
  await s.start();   // starts again with the same link
  assert.equal((await request(s.port, 'GET', '/abcdefgh23/ping')).status, 200);
  s.stop();
  console.log('PASS phone: formats, addresses, QR and WiFi codes, secret link, uploads and limits');
})().catch(e => { console.error('FAIL phone', e); process.exit(1); });
