// Voice model unpacking tests: node tests/voice.test.cjs
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const V = require('../voice-models');

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dotsense-voice-'));
  const name = V.MODELS.fast.name;
  const src = path.join(root, 'src', name);
  fs.mkdirSync(path.join(src, 'test_wavs'), { recursive: true });
  const content = {};
  for (const f of V.MODEL_FILES) { content[f] = Buffer.from(f + ':' + 'x'.repeat(50000 + f.length)); fs.writeFileSync(path.join(src, f), content[f]); }
  fs.writeFileSync(path.join(src, 'test_wavs', '0.wav'), 'RIFF');
  const archive = path.join(root, name + '.tar.bz2');
  try { execFileSync('tar', ['-cjf', archive, '-C', path.join(root, 'src'), name]); }
  catch (e) { console.log('SKIP voice: system tar with bzip2 not available'); return; }

  for (const noSystemTar of [true, false]) {
    const modelsDir = path.join(root, noSystemTar ? 'js' : 'tar');
    const dir = path.join(modelsDir, name);
    fs.mkdirSync(modelsDir, { recursive: true });
    fs.writeFileSync(path.join(modelsDir, V.VAD_FILE), 'vad');
    assert.equal(V.installed(modelsDir).fast.installed, false);
    await V.unpack(archive, modelsDir, dir, { noSystemTar });
    for (const f of V.MODEL_FILES) assert.deepEqual(fs.readFileSync(path.join(dir, f)), content[f], f);
    assert.equal(fs.existsSync(path.join(dir, 'test_wavs')), false);
    assert.equal(fs.readdirSync(dir).some(f => f.endsWith('.part')), false);
    assert.equal(V.installed(modelsDir).fast.installed, true);
    assert.equal(V.installed(modelsDir).accurate.installed, false);
  }
  // the Bangla streaming model (four files, extras left out)
  const bnName = V.MODELS.bangla.name;
  const bnSrc = path.join(root, 'src', bnName);
  fs.mkdirSync(path.join(bnSrc, 'test_wavs'), { recursive: true });
  const bnContent = {};
  for (const f of V.ZIPFORMER_FILES) { bnContent[f] = Buffer.from(f + ':' + 'y'.repeat(40000 + f.length)); fs.writeFileSync(path.join(bnSrc, f), bnContent[f]); }
  for (const extra of ['bpe.model', 'unigram_500.vocab', 'README.md']) fs.writeFileSync(path.join(bnSrc, extra), extra);
  fs.writeFileSync(path.join(bnSrc, 'test_wavs', '0.wav'), 'RIFF');
  const bnArchive = path.join(root, bnName + '.tar.bz2');
  execFileSync('tar', ['-cjf', bnArchive, '-C', path.join(root, 'src'), bnName]);
  for (const noSystemTar of [true, false]) {
    const modelsDir = path.join(root, 'bn-' + (noSystemTar ? 'js' : 'tar'));
    const dir = path.join(modelsDir, bnName);
    fs.mkdirSync(modelsDir, { recursive: true });
    fs.writeFileSync(path.join(modelsDir, V.VAD_FILE), 'vad');
    assert.equal(V.installed(modelsDir).bangla.installed, false);
    await V.unpack(bnArchive, modelsDir, dir, { noSystemTar }, V.MODELS.bangla.files);
    for (const f of V.ZIPFORMER_FILES) assert.deepEqual(fs.readFileSync(path.join(dir, f)), bnContent[f], f);
    assert.deepEqual(fs.readdirSync(dir).sort(), [...V.ZIPFORMER_FILES].sort(), 'only the model files are kept');
    assert.equal(V.installed(modelsDir).bangla.installed, true);
    assert.equal(V.installed(modelsDir).bangla.lang, 'bn');
  }
  // a broken archive is reported, not half-installed
  const bad = path.join(root, 'bad.tar.bz2');
  fs.writeFileSync(bad, 'not an archive');
  await assert.rejects(V.unpack(bad, path.join(root, 'bad'), path.join(root, 'bad', name), { noSystemTar: true }));
  fs.rmSync(root, { recursive: true, force: true });
  console.log('PASS voice: model unpacking (JavaScript and system tar)');
})().catch(e => { console.error('FAIL voice', e); process.exit(1); });
