// Machine WiFi tests: node tests/wifi.test.cjs
const assert = require('node:assert/strict');
const { execFileSync } = require('child_process');
const path = require('path');
const W = require('../wifi');

// ---- Windows: netsh wlan show interfaces
const netshOn = `
There is 1 interface on the system:

    Name                   : Wi-Fi
    Description            : Intel(R) Wi-Fi 6 AX201 160MHz
    GUID                   : 4a1e2c3d-0000-4000-8000-123456789abc
    Physical address       : 3c:58:c2:11:22:33
    Interface type         : Primary
    State                  : connected
    SSID                   : MKS_DLC
    AP BSSID               : 24:0a:c4:aa:bb:cc
    Band                   : 2.4 GHz
    Channel                : 1
    Network type           : Infrastructure
    Radio type             : 802.11n
    Authentication         : WPA2-Personal
    Cipher                 : CCMP
    Connection mode        : Profile
    Profile                : MKS_DLC

    Hosted network status  : Not available
`;
const netshOld = netshOn.replace('    AP BSSID               :', '    BSSID                  :');
const netshOff = `
There is 1 interface on the system:

    Name                   : WLAN
    Description            : Realtek RTL8821CE 802.11ac PCIe Adapter
    State                  : disconnected
    Radio status           : Hardware On
                             Software On
`;
const netshLocation = `Network shell commands need location permission to access WLAN information. Turn on Location services on the Location page in Privacy & security settings.

Here is the URI for the Location page in the Settings app:
    ms-settings:privacy-location
To open the Location page in the Settings app, hold down the Ctrl key and select the link, or run the following command:
    start ms-settings:privacy-location
Function WlanQueryInterface returns error 5:
The requested operation requires elevation (Run as administrator).
`;
assert.deepEqual(W.parseNetsh(netshOn), { available: true, ssid: 'MKS_DLC' });
assert.deepEqual(W.parseNetsh(netshOld), { available: true, ssid: 'MKS_DLC' }, 'the BSSID line is not the name');
assert.deepEqual(W.parseNetsh(netshOff), { available: true, ssid: '' });
assert.deepEqual(W.parseNetsh(netshOn.replace('MKS_DLC\n', 'My Home WiFi 5G  \n')).ssid, 'My Home WiFi 5G');
assert.equal(W.netshNeedsLocation(netshLocation), true);
assert.equal(W.netshNeedsLocation(netshOn), false);
assert.equal(W.netshNeedsLocation(netshOff), false);

// ---- Linux: nmcli
assert.deepEqual(W.parseNmcli('no:Neighbours\nyes:MKS_DLC\nno:\n'), { available: true, ssid: 'MKS_DLC' });
assert.deepEqual(W.parseNmcli('no:MKS_DLC\n'), { available: true, ssid: '' });
assert.equal(W.parseNmcli('yes:My\\:Net\\\\5\n').ssid, 'My:Net\\5');
assert.equal(W.nmcliHasWifi('ethernet:connected\nwifi:disconnected\nloopback:unmanaged\n'), true);
assert.equal(W.nmcliHasWifi('ethernet:connected\nloopback:unmanaged\n'), false);

// ---- macOS: networksetup
assert.deepEqual(W.parseAirport('Current Wi-Fi Network: MKS_DLC\n'), { available: true, ssid: 'MKS_DLC' });
assert.deepEqual(W.parseAirport('You are not associated with an AirPort network.\n'), { available: true, ssid: '' });
assert.equal(W.parseAirport('en7 is not a Wi-Fi interface.\n** Error: Error obtaining wireless information.').available, false);
const ports = 'Hardware Port: Ethernet\nDevice: en0\nEthernet Address: 00:11\n\nHardware Port: Wi-Fi\nDevice: en1\nEthernet Address: 00:22\n';
assert.equal(W.macWifiDevice(ports), 'en1');
assert.equal(W.macWifiDevice(''), 'en0');

// ---- names
assert.ok(W.sameNetwork('MKS_DLC', 'MKS_DLC'));
assert.ok(W.sameNetwork('MKS_DLC 2', 'MKS_DLC'), 'Windows network list numbering');
assert.ok(!W.sameNetwork('MKS_DLC2', 'MKS_DLC'));
assert.ok(!W.sameNetwork('', 'MKS_DLC'));
assert.equal(W.DEFAULTS.ssid, 'MKS_DLC');
assert.equal(W.DEFAULTS.password, '12345678');

// ---- Windows profile (XML-safe; open network without a password)
const p = W.windowsProfile('A&B <"x">', "p&ss'<>word");
assert.ok(p.includes('<name>A&amp;B &lt;&quot;x&quot;&gt;</name>'));
assert.ok(p.includes('<keyMaterial>p&amp;ss&apos;&lt;&gt;word</keyMaterial>'));
assert.ok(p.includes('<authentication>WPA2PSK</authentication>') && p.includes('<connectionMode>manual</connectionMode>'));
const open = W.windowsProfile('Open', '');
assert.ok(open.includes('<authentication>open</authentication>') && !open.includes('keyMaterial'));

// ---- messages
assert.match(W.joinError('The network specified by profile "MKS_DLC" is not available to connect.', 'MKS_DLC'), /not found\. Is the machine switched on/);
assert.match(W.joinError('Error: No network with SSID "MKS_DLC" found.', 'MKS_DLC'), /not found/);
assert.match(W.joinError('Error: Connection activation failed: Secrets were required, but not provided.', 'MKS_DLC'), /Wrong password/);
assert.match(W.joinError(netshLocation, 'MKS_DLC'), /Location/);

(async () => {
  await assert.rejects(W.connect('', '12345678'), /Enter the WiFi name/);
  await assert.rejects(W.connect('MKS_DLC', '1234'), /8 to 63 characters/);
  await assert.rejects(W.connect('x'.repeat(33), '12345678'), /at most 32/);
  // the pretend WiFi used by the app tests
  const script = `const W = require(${JSON.stringify(path.join(__dirname, '..', 'wifi.js'))});
    (async () => {
      const out = [(await W.status()).ssid];
      try { await W.connect('MKS_DLC', 'wrong-pass'); } catch (e) { out.push(e.message); }
      out.push((await W.connect('MKS_DLC', '12345678')).ssid, (await W.status()).ssid);
      console.log(JSON.stringify(out));
    })();`;
  const out = JSON.parse(execFileSync(process.execPath, ['-e', script], { env: Object.assign({}, process.env, { DOTSENSE_WIFI_FAKE: '1' }) }).toString());
  assert.deepEqual(out, ['HomeNet', 'Wrong password for “MKS_DLC”?', 'MKS_DLC', 'MKS_DLC']);
  console.log('PASS wifi: status parsers (Windows, Linux, macOS), profile, messages, pretend WiFi');
})().catch(e => { console.error('FAIL wifi', e); process.exit(1); });
